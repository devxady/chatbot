<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LeadBee_Public {
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_footer', array( $this, 'render_widget' ) );
	}

	private function visible_on_current_page() {
		$general = LeadBee_Admin::settings( 'general' );
		if ( empty( $general['enabled'] ) ) {
			return false;
		}
		$mode = $general['display_rule'];
		$ids  = array_filter( array_map( 'absint', explode( ',', $general['page_ids'] ) ) );
		if ( 'home' === $mode && ! is_front_page() ) {
			return false;
		}
		if ( 'selected' === $mode && ! in_array( get_queried_object_id(), $ids, true ) ) {
			return false;
		}
		if ( 'hidden' === $mode && is_singular() && in_array( get_queried_object_id(), $ids, true ) ) {
			return false;
		}
		return true;
	}

	public function enqueue_assets() {
		if ( ! $this->visible_on_current_page() ) {
			return;
		}
		$appearance = LeadBee_Admin::settings( 'appearance' );
		$general    = LeadBee_Admin::settings( 'general' );
		$kb         = LeadBee_Knowledge_Base::active();
		wp_enqueue_style( 'leadbee-chatbot', LEADBEE_URL . 'public/assets/css/chatbot.css', array(), filemtime( LEADBEE_PATH . 'public/assets/css/chatbot.css' ) );
		wp_enqueue_style( 'leadbee-settings', LEADBEE_URL . 'public/assets/css/chatbot-settings.css', array( 'leadbee-chatbot' ), filemtime( LEADBEE_PATH . 'public/assets/css/chatbot-settings.css' ) );
		wp_enqueue_script( 'leadbee-chatbot', LEADBEE_URL . 'public/assets/js/chatbot.js', array(), filemtime( LEADBEE_PATH . 'public/assets/js/chatbot.js' ), true );
		$config = array(
			'knowledgeBaseData' => $kb,
			'endpoint'          => esc_url_raw( rest_url( 'leadbee/v1/leads' ) ),
			'restNonce'         => wp_create_nonce( 'wp_rest' ),
			'minimumThinkMs'    => absint( $appearance['typing_min'] ),
			'maximumThinkMs'    => absint( $appearance['typing_max'] ),
			'greeting'          => sanitize_text_field( $general['greeting'] ),
			'fallbackBehaviour' => sanitize_key( $general['fallback_behaviour'] ),
			'assistantName'     => sanitize_text_field( $appearance['assistant_name'] ),
			'suggestions'       => ! empty( $general['suggestions'] ),
			'maxSuggestions'    => absint( $general['max_suggestions'] ),
			'matchSensitivity'  => absint( $general['match_sensitivity'] ),
			'smallTalk'         => ! empty( $general['small_talk'] ),
			'sessionPersistence'=> ! empty( $general['session_persistence'] ),
			'leadCollection'    => ! empty( $general['lead_collection'] ),
			'appearance'        => $appearance,
			'contacts'          => LeadBee_Admin::settings( 'contacts' ),
		);
		wp_add_inline_script( 'leadbee-chatbot', 'window.YELLO_CONFIG = ' . wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ';', 'before' );
	}

	public function render_widget() {
		if ( ! $this->visible_on_current_page() ) {
			return;
		}
		$appearance = LeadBee_Admin::settings( 'appearance' );
		$general    = LeadBee_Admin::settings( 'general' );
		$contacts   = LeadBee_Admin::settings( 'contacts' );
		$kb         = LeadBee_Knowledge_Base::active();
		$css        = self::css_variables( $appearance );
		$device     = array();
		if ( empty( $general['show_desktop'] ) ) {
			$device[] = 'leadbee-hide-desktop';
		}
		if ( empty( $general['show_tablet'] ) ) {
			$device[] = 'leadbee-hide-tablet';
		}
		if ( empty( $general['show_mobile'] ) ) {
			$device[] = 'leadbee-hide-mobile';
		} else {
			$device[] = 'leadbee-show-mobile';
		}
		if ( empty( $appearance['animations'] ) ) { $device[] = 'leadbee-no-animation'; }
		if ( empty( $appearance['window_animation'] ) ) { $device[] = 'leadbee-no-window-animation'; }
		if ( empty( $appearance['button_hover'] ) ) { $device[] = 'leadbee-no-button-hover'; }
		if ( ! empty( $appearance['launcher_pulse'] ) ) { $device[] = 'leadbee-launcher-pulse'; }
		if ( 'left' === $appearance['desktop_position'] ) { $device[] = 'leadbee-pos-left'; }
		$device[] = 'left' === $appearance['mobile_position'] ? 'leadbee-mobile-left' : 'leadbee-mobile-right';
		$root_class = implode( ' ', $device );
		include LEADBEE_PATH . 'public/views/chatbot-widget.php';
	}

	private static function css_variables( $settings ) {
		$variables = array(
			'--yellow'       => $settings['primary_color'],
			'--lb-secondary' => $settings['secondary_color'],
			'--lb-accent'    => $settings['accent_color'],
			'--ink'          => $settings['text_color'],
			'--muted'        => $settings['muted_color'],
			'--line'         => $settings['border_color'],
			'--soft'         => $settings['soft_color'],
			'--lb-header'    => $settings['header_background'],
			'--lb-welcome'   => $settings['welcome_background'],
			'--lb-convo'     => $settings['conversation_background'],
			'--lb-user'      => $settings['user_bubble'],
			'--lb-bot'       => $settings['bot_bubble'],
			'--lb-user-text' => $settings['user_text'],
			'--lb-bot-text'  => $settings['bot_text'],
			'--lb-button'    => $settings['button_background'],
			'--lb-button-text'=> $settings['button_text'],
			'--lb-input'     => $settings['input_background'],
			'--lb-input-border'=> $settings['input_border'],
			'--lb-footer'    => $settings['footer_background'],
			'--lb-status'    => $settings['status_color'],
			'--lb-link'      => $settings['link_color'],
			'--lb-hover'     => $settings['hover_color'],
		);
		$family = in_array( $settings['font_family'], array( 'Plus Jakarta Sans', 'Arial', 'system-ui' ), true ) ? $settings['font_family'] : 'Plus Jakarta Sans';
		$variables['--lb-font'] = $family . ', system-ui, sans-serif';
		$mobile_scale = max( 0.85, min( 1.15, (float) $settings['mobile_font_scale'] ) );
		$style = '';
		foreach ( $variables as $key => $value ) {
			$style .= $key . ':' . esc_attr( $value ) . ';';
		}
		$style .= '--lb-base-size:' . absint( $settings['base_font_size'] ) . 'px;';
		$style .= '--lb-heading-size:' . absint( $settings['heading_font_size'] ) . 'px;';
		$style .= '--lb-line-height:' . esc_attr( $settings['line_height'] ) . ';';
		$style .= '--lb-font-weight:' . absint( $settings['font_weight'] ) . ';';
		$style .= '--lb-button-weight:' . absint( $settings['button_font_weight'] ) . ';';
		$style .= '--lb-panel-width:' . absint( $settings['panel_width'] ) . 'px;';
		$style .= '--lb-panel-height:' . absint( $settings['panel_height'] ) . 'px;';
		$style .= '--lb-panel-right:calc(' . absint( $settings['right_offset'] ) . 'px + 8px);';
		$style .= '--lb-radius:' . absint( $settings['border_radius'] ) . 'px;';
		$style .= '--lb-launcher-size:' . absint( $settings['launcher_size'] ) . 'px;';
		$style .= '--lb-shadow:' . number_format( min( 0.8, max( 0, absint( $settings['shadow_intensity'] ) / 100 ) ), 2, '.', '' ) . ';';
		$style .= '--lb-secondary-button:' . esc_attr( $settings['secondary_button_background'] ) . ';';
		$style .= '--lb-secondary-button-text:' . esc_attr( $settings['secondary_button_text'] ) . ';';
		$style .= '--lb-bottom:' . absint( $settings['bottom_offset'] ) . 'px;';
		$style .= '--lb-right:' . absint( $settings['right_offset'] ) . 'px;';
		$style .= '--lb-mobile-width:' . absint( $settings['mobile_panel_width'] ) . 'px;';
		$style .= '--lb-mobile-height:' . absint( $settings['mobile_panel_height'] ) . 'px;';
		$style .= '--lb-mobile-bottom:' . absint( $settings['mobile_bottom_offset'] ) . 'px;';
		$style .= '--lb-mobile-side:' . absint( $settings['mobile_side_offset'] ) . 'px;';
		$style .= '--lb-mobile-radius:' . absint( $settings['mobile_border_radius'] ) . 'px;';
		$style .= '--lb-mobile-font-scale:' . number_format( $mobile_scale, 2, '.', '' ) . ';';
		$style .= '--lb-mobile-launcher-size:' . absint( $settings['mobile_launcher_size'] ) . 'px;';
		$style .= '--lb-mobile-heading-size:' . number_format( min( 25, max( 23, absint( $settings['heading_font_size'] ) * $mobile_scale ) ), 1, '.', '' ) . 'px;';
		$style .= '--lb-mobile-description-size:' . number_format( min( 13, max( 12, absint( $settings['base_font_size'] ) * 0.97 * $mobile_scale ) ), 1, '.', '' ) . 'px;';
		$style .= '--lb-mobile-header-size:' . number_format( min( 14, max( 13, 14 * $mobile_scale ) ), 1, '.', '' ) . 'px;';
		$style .= '--lb-mobile-subtitle-size:' . number_format( min( 10, max( 9, 9.5 * $mobile_scale ) ), 1, '.', '' ) . 'px;';
		$style .= '--lb-mobile-message-size:' . number_format( min( 13, max( 12, absint( $settings['base_font_size'] ) * 0.94 * $mobile_scale ) ), 1, '.', '' ) . 'px;';
		$style .= '--lb-mobile-chip-size:' . number_format( min( 11, max( 10, 10.5 * $mobile_scale ) ), 1, '.', '' ) . 'px;';
		$style .= '--lb-mobile-input-size:' . number_format( min( 13, max( 12, 12.5 * $mobile_scale ) ), 1, '.', '' ) . 'px;';
		$style .= '--lb-mobile-button-size:' . number_format( min( 12, max( 11, 11.5 * $mobile_scale ) ), 1, '.', '' ) . 'px;';
		$style .= '--lb-mobile-footer-size:' . number_format( min( 10, max( 9, 9 * $mobile_scale ) ), 1, '.', '' ) . 'px;';
		return $style;
	}
}
