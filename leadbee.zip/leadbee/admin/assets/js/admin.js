(function ($) {
  'use strict';
  $(document).on('change', '.leadbee-select-all', function () {
    $(this).closest('form').find('input[name="lead_ids[]"]').prop('checked', this.checked);
  });
  $(document).on('click', '.leadbee-media-select', function (event) {
    event.preventDefault();
    const target = $('#' + $(this).data('target'));
    const frame = wp.media({ title: 'Choose an avatar image', button: { text: 'Use this image' }, library: { type: ['image'] }, multiple: false });
    frame.on('select', function () {
      const attachment = frame.state().get('selection').first().toJSON();
      if (!attachment || !attachment.url || !/^image\/(png|jpeg|webp|gif)$/.test(attachment.mime)) return;
      target.val(attachment.url).trigger('input');
      let preview = target.closest('td').find('.leadbee-media-preview');
      if (!preview.length) preview = $('<img class="leadbee-media-preview" alt="">').appendTo(target.closest('td'));
      preview.attr('src', attachment.url);
    });
    frame.open();
  });
  $(document).on('click', '[data-preview-screen]', function () {
    const screen = $(this).data('preview-screen');
    $('[data-preview-screen]').removeClass('is-active');
    $(this).addClass('is-active');
    $('.lb-preview-welcome').prop('hidden', screen !== 'welcome');
    $('.lb-preview-chat').prop('hidden', screen !== 'chat');
  });
  $(document).on('change', '.leadbee-preview-mobile', function () {
    $('#leadbeeLivePreview').toggleClass('is-mobile', this.checked);
    updatePreview();
  });
  function updatePreview() {
    const preview = $('#leadbeeLivePreview');
    const rootVars = { primary_color: '--p', user_bubble: '--p', button_background: '--p', bot_bubble: '--bot', text_color: 'color', secondary_button_background: '--secondary' };
    Object.keys(rootVars).forEach(function (key) {
      const field = $('#leadbee_appearance_' + key);
      if (field.length) preview.css(rootVars[key], field.val());
    });
    const header = $('#leadbee_appearance_header_background').val();
    const welcome = $('#leadbee_appearance_welcome_background').val();
    if (header) preview.find('.lb-preview-head').css('backgroundColor', header);
    if (welcome) preview.find('.lb-preview-welcome').css('backgroundColor', welcome);
    const font = $('#leadbee_appearance_font_family').val();
    if (font) preview.css('fontFamily', font + ', system-ui, sans-serif');
    const headingSize = $('#leadbee_appearance_heading_font_size').val();
    if (headingSize) preview.find('.lb-preview-welcome h3').css('fontSize', Math.max(18, Math.min(42, Number(headingSize))) + 'px');
    const heading = $('#leadbee_appearance_welcome_heading').val();
    const welcomeIcon = $('#leadbee_appearance_welcome_icon').val() || '';
    if (heading) preview.find('.lb-preview-welcome h3').text(heading + ' ' + welcomeIcon).css('whiteSpace', 'pre-line');
    const description = $('#leadbee_appearance_welcome_description').val();
    if (description) preview.find('.lb-preview-welcome p').text(description);
    const assistant = $('#leadbee_appearance_assistant_name').val();
    if (assistant) preview.find('.lb-preview-assistant').contents().first()[0].textContent = assistant;
    const status = $('#leadbee_appearance_status_text').val();
    if (status) preview.find('.lb-preview-assistant small').text('● ' + status);
    const isMobile = preview.hasClass('is-mobile');
    const size = $('#leadbee_appearance_panel_width').val();
    if (size && !isMobile) preview.css('max-width', Math.max(320, Math.min(600, Number(size))) + 'px');
    if (isMobile) {
      const mobileWidth = Number($('#leadbee_appearance_mobile_panel_width').val() || 580);
      const sideOffset = Number($('#leadbee_appearance_mobile_side_offset').val() || 12);
      const mobileHeight = Number($('#leadbee_appearance_mobile_panel_height').val() || 580);
      const radius = Number($('#leadbee_appearance_mobile_border_radius').val() || 22);
      const scale = Number($('#leadbee_appearance_mobile_font_scale').val() || 1);
      preview.css({
        width: Math.max(220, Math.min(280, mobileWidth, 320 - 2 * sideOffset)) + 'px',
        height: Math.max(280, Math.min(450, mobileHeight)) + 'px',
        borderRadius: Math.max(12, Math.min(32, radius)) + 'px'
      });
      if (headingSize) preview.find('.lb-preview-welcome h3').css('fontSize', Math.max(23, Math.min(25, Number(headingSize) * scale)) + 'px');
    } else {
      preview.css({ width: '100%', height: '450px', borderRadius: '17px' });
    }
  }
  $(document).on('input change', '.leadbee-settings-form input,.leadbee-settings-form textarea,.leadbee-settings-form select', updatePreview);
  $(function () {
    $('#leadbee_general_display_rule').on('change', function () {
      $('#leadbee_general_page_ids').closest('tr').toggle(['selected', 'hidden'].includes(this.value));
    }).trigger('change');
    $('#leadbee_email_method').on('change', function () {
      const custom = this.value === 'custom';
      ['smtp_host','smtp_port','smtp_encryption','smtp_auth','smtp_username','smtp_password'].forEach(function (key) {
        $('#leadbee_email_' + key).closest('tr').toggle(custom);
      });
    }).trigger('change');
    updatePreview();
  });
})(jQuery);
