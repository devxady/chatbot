# Changelog

## 1.0.0 — 4 November 2026

- Ported the existing Yello chatbot interface and JSON-driven rule engine into a WordPress plugin.
- Added explicit confirmation and secure, idempotent lead submission to a prefix-aware database table.
- Added private lead list, filters, detail transcripts, notes, status updates, CSV export, and deletion.
- Added dashboard metrics, knowledge-base validation and preview imports, backups, restore and export.
- Added appearance, contact, visibility, general, and WordPress/custom SMTP settings.
- Added per-control bundled icon presets, configurable welcome icon, typography scaling, and fallback-style control.
- Added a deactivation dialog for retaining or deleting LeadBee data, and retry controls for failed lead notifications.
- Let the existing WordPress mailer control sender identity in WordPress email mode for SMTP-plugin compatibility.
- Updated admin typography, lead table spacing, knowledge-base action alignment, and supplied contact icons.
- Prevented weekday and time availability replies from being captured as a lead's name.
- Prevented consent/action text from being captured as a name, repaired stale unsent chat sessions, and added a skippable email prompt before the address question.
- Kept personal details out of persistent browser storage after successful submission.
