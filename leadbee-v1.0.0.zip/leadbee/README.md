# LeadBee v1.0.0

LeadBee is a WordPress conversational chatbot and lead management plugin, authored by devxady. Its visitor-facing assistant retains the Yello Driving School name and the supplied chat design. The internal plugin name is LeadBee.

## Install

1. In WordPress, open **Plugins → Add New Plugin → Upload Plugin**.
2. Upload `leadbee-v1.0.0.zip`, then activate LeadBee.
3. Open **LeadBee → Contact Settings** and enter the business's current contact destinations. The sample HTML's phone and email values were preview placeholders and are intentionally not prefilled.
4. Choose the notification recipient and mail transport under **Email Settings**.
5. Check **General Settings**, then open the live site and submit a test enquiry.

The plugin creates a table using the active WordPress database prefix. Clicking LeadBee’s **Deactivate** action opens a choice to keep its data or permanently delete leads, transcripts, notes, settings and the active knowledge base. Uninstalling keeps data by default unless **Delete plugin data on uninstall** was enabled in General Settings before uninstall.

## Conversation and enquiries

The rule-based browser engine uses the full bundled JSON knowledge base. It does not call a paid AI service and does not claim to provide generative or semantic AI. Current FAQ answers, routing policy, lead capture rules, fallbacks, business profile, and pricing remain in the active JSON.

The enquiry flow requires lesson type, preferred availability, full name, a UK phone number, and address or postcode. Email is optional. Visitors review a summary and must confirm it before the browser sends it to the WordPress REST endpoint. The server validates the fields again, applies a honeypot and per-IP rate limit, saves the transcript and data, and returns success only after the database write succeeds. A retry uses the same idempotency key. Email delivery is attempted after saving; mail failure does not remove the lead.

Lead records are only shown in the administrator dashboard to users with `manage_options`. The public REST route accepts validated submissions; it has no lead-reading route.

## Settings

- **Dashboard:** Database-backed lead counts, mail failures, chatbot status, knowledge-base health, and recent leads.
- **Leads:** Search and filter by status, lesson type and date; sort, paginate, view transcripts, add private notes, update status, export filtered CSV, and delete records.
- **Knowledge Base:** Validate JSON syntax and required sections, preview imports, confirm replacements, export the active file, and restore the bundled default. Three previous active copies are kept as backups. Lead records are unaffected.
- **Appearance:** Brand text, image avatar, colours, typography, layout, per-control bundled icon choices, animations, and an editable welcome/conversation preview.
- **Contact Settings:** Business details and individually enabled WhatsApp, email, phone, website and privacy destinations. An empty destination is not rendered as a contact card.
- **Email Settings:** `wp_mail()` by default, or LeadBee-only SMTP configuration. SMTP passwords are encrypted using the site's WordPress authentication salt and are never sent to the browser. The test email reports the active transport and recipient; failed notifications can be retried from a lead record.
- **General Settings:** Enablement, page rules, device visibility, suggested questions, matching sensitivity, session persistence, fallback style, and data retention.

## Email

The default method calls `wp_mail()` and therefore uses the site's existing mail configuration or a compatible WordPress SMTP plugin such as WP Mail SMTP. In this mode LeadBee leaves the sender identity to the configured mailer, avoiding an overridden From address. Custom SMTP uses WordPress's bundled PHPMailer only during LeadBee notification sends, so it does not change mail settings for other plugins. The test email sends through the selected transport and reports connection, authentication, or delivery errors in Email Settings. Failed or pending lead notifications can be retried from the lead detail page. SMTP password storage requires PHP OpenSSL; if OpenSSL is unavailable, saving a new password is rejected.

## Privacy and storage

Before submission, the active conversation is held in this browser tab's `sessionStorage` when persistence is enabled. It is not written to `localStorage`. After a successful database save, the stored personal fields and prior transcript are removed from the tab state. The server stores the lead and conversation transcript in the WordPress database. Site owners should document their own privacy notice and access policy. Automatic retention is disabled by default; administrators can set a deletion period in General Settings. LeadBee provides manual deletion and a keep-or-delete choice on deactivation; uninstall preserves data by default.

## Compatibility

- WordPress 6.0 or later
- PHP 7.4 or later
- Ordinary WordPress PHP/MySQL hosting
- No Node.js, Composer, Python, Redis, WebSockets, VPS, or external AI API required

The widget CSS is scoped to `.leadbee-root`; reduced-motion preferences are respected. Modern browser support is expected for sessionStorage, Fetch, and Unicode regular expressions.

## Local verification

Local checks passed for PHP syntax (PHP 8.0 and 8.4), JavaScript syntax, the bundled knowledge-base schema and its 200 Q&A records, and UK phone validation examples. A mocked browser harness also covered small talk, lesson-interest routing, multi-field capture, optional email, explicit confirmation, verified submission success, retry after failure, active-JSON pricing, driving-only fallback, session restoration, and Start New Chat clearing.

## Known delivery limits

The supplied workspace does not include a running WordPress site, a configured database, or mail credentials. Database installation, live REST submission, WordPress admin rendering, theme compatibility, and actual email delivery remain to be confirmed on a staging WordPress site.
