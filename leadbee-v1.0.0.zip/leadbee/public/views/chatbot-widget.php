<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$kb_profile = isset( $kb['business_profile'] ) && is_array( $kb['business_profile'] ) ? $kb['business_profile'] : array();
$display_name = sanitize_text_field( $appearance['display_name'] );
$assistant_name = sanitize_text_field( $appearance['assistant_name'] );
$heading = sanitize_textarea_field( $appearance['welcome_heading'] );
$welcome_icon = sanitize_text_field( $appearance['welcome_icon'] );
$business_name = sanitize_text_field( ! empty( $contacts['business_name'] ) ? $contacts['business_name'] : ( isset( $kb_profile['name'] ) ? $kb_profile['name'] : $display_name ) );
$description = sanitize_textarea_field( $appearance['welcome_description'] );
$subtitle = sanitize_text_field( $appearance['header_subtitle'] );
$status = sanitize_text_field( $appearance['status_text'] );
$footer = sanitize_text_field( $appearance['footer_text'] );
$privacy_url = ! empty( $contacts['privacy_url'] ) ? esc_url( $contacts['privacy_url'] ) : '';
$logo_url = ! empty( $appearance['avatar_url'] ) ? esc_url( $appearance['avatar_url'] ) : '';
$launcher_text = ! empty( $general['launcher_text_enabled'] ) ? sanitize_text_field( $general['launcher_text'] ) : '';
$show_whatsapp = ! empty( $contacts['whatsapp_enabled'] ) && ! empty( $contacts['whatsapp'] );
$whatsapp = preg_replace( '/\D+/', '', $contacts['whatsapp'] );
if ( 0 === strpos( $whatsapp, '00' ) ) { $whatsapp = substr( $whatsapp, 2 ); }
$show_email = ! empty( $contacts['email_enabled'] ) && is_email( $contacts['email'] );
$show_call = ! empty( $contacts['call_enabled'] ) && ! empty( $contacts['phone'] );
$show_website = ! empty( $contacts['website_enabled'] ) && wp_http_validate_url( $contacts['website'] );
$show_additional_phone = ! empty( $contacts['additional_phone'] );
$show_additional_email = is_email( $contacts['additional_email'] );
$show_more = ! empty( $contacts['more_enabled'] ) && ( $show_call || $show_website || $show_additional_phone || $show_additional_email );
$launcher_icon = 'spark' === $general['launcher_icon'] ? 'ic-spark' : 'ic-chat';
$avatar_icon = 'spark' === $appearance['avatar_icon'] ? 'ic-spark' : 'ic-chat';
?>
<div class="leadbee-root <?php echo esc_attr( $root_class ); ?>" style="<?php echo esc_attr( $css ); ?>" data-leadbee="1">
  <svg xmlns="http://www.w3.org/2000/svg" class="svg-icons" aria-hidden="true">
    <symbol id="ic-chat" viewBox="0 0 24 24"><path d="M20 11.5a8.5 8.5 0 0 1-8.5 8.5 9 9 0 0 1-4-.95L3 20l1-4.2a8.5 8.5 0 1 1 16-4.3Z"/><path d="M8 10h8M8 14h5"/></symbol>
    <symbol id="ic-whatsapp" viewBox="0 0 32 32"><path fill="currentColor" d="M16 3A13 13 0 0 0 4.8 22.6L3 29l6.6-1.7A13 13 0 1 0 16 3Zm0 23.7c-2.1 0-4.2-.6-6-1.7l-.4-.2-3.9 1 1-3.8-.3-.4a10.7 10.7 0 1 1 9.6 5.1Zm6-8c-.3-.2-1.9-.9-2.2-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-1.9-.9-3.2-2.3-4.1-4.1-.2-.3 0-.5.1-.7l.5-.6c.2-.2.2-.4.3-.6 0-.2 0-.4-.1-.6l-1-2.4c-.3-.7-.6-.6-.8-.6h-.7c-.3 0-.7.1-1 .5s-1.3 1.3-1.3 3.1 1.3 3.4 1.6 3.5 3.5 5.1 5.4 2.8c1.6.5 3 .4 4.1.2 1.2-.2 1.9-1 2.1-1.8.3-.8.3-1.5.2-1.7-.1-.2-.3-.3-.6-.4Z"/></symbol>
    <symbol id="ic-arrow" viewBox="0 0 24 24"><path d="M4 12h16M14 6l6 6-6 6"/></symbol>
    <symbol id="ic-mail" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></symbol>
    <symbol id="ic-phone" viewBox="0 0 24 24"><path d="M6 3h4l1 5-2.5 2a15 15 0 0 0 5.5 5.5L16 13l5 1v4a3 3 0 0 1-3 3C10 21 3 14 3 6a3 3 0 0 1 3-3Z"/></symbol>
    <symbol id="ic-web" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></symbol>
    <symbol id="ic-shield" viewBox="0 0 24 24"><path d="m12 2 8 4v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6l8-4Z"/><path d="m9 12 2 2 4-4"/></symbol>
    <symbol id="ic-back" viewBox="0 0 24 24"><path d="m15 18-6-6 6-6"/></symbol>
    <symbol id="ic-close" viewBox="0 0 24 24"><path d="M5 5l14 14M19 5 5 19"/></symbol>
    <symbol id="ic-restart" viewBox="0 0 24 24"><path d="M4 11a8 8 0 1 0 2-5M4 4v5h5"/></symbol>
    <symbol id="ic-spark" viewBox="0 0 24 24"><path d="m12 2 1.8 7.1L21 12l-7.2 2.9L12 22l-1.8-7.1L3 12l7.2-2.9L12 2Z"/><path d="m19 2 .6 2.4L22 5l-2.4.6L19 8l-.6-2.4L16 5l2.4-.6L19 2Z"/></symbol>
  </svg>
  <div class="launcher-wrap" id="launcherWrap">
    <?php if ( $launcher_text ) : ?><span class="launcher-tip"><?php echo esc_html( $launcher_text ); ?></span><?php endif; ?>
    <button id="launcher" class="chat-launcher" aria-label="<?php esc_attr_e( 'Open Yello chatbot', 'leadbee' ); ?>" type="button"><svg class="ico"><use href="#<?php echo esc_attr( $launcher_icon ); ?>"/></svg></button>
  </div>
  <section id="panel" class="panel" aria-label="<?php echo esc_attr( $display_name ); ?> chat" hidden>
    <header class="header">
      <span class="avatar"><?php if ( $logo_url ) : ?><img src="<?php echo esc_url( $logo_url ); ?>" alt="" /><?php else : ?><svg class="ico"><use href="#<?php echo esc_attr( $avatar_icon ); ?>"/></svg><?php endif; ?></span>
      <div class="headtext"><strong><?php echo esc_html( $assistant_name ); ?></strong><small><span class="online"></span><?php echo esc_html( $status ); ?></small></div>
      <div class="head-actions"><button type="button" class="iconbtn" id="back" aria-label="<?php esc_attr_e( 'Back to welcome', 'leadbee' ); ?>" hidden><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['back_icon'] ); ?>"/></svg></button><button type="button" class="iconbtn" id="restart" aria-label="<?php esc_attr_e( 'Start new conversation', 'leadbee' ); ?>" title="<?php esc_attr_e( 'Start a new conversation', 'leadbee' ); ?>"><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['restart_icon'] ); ?>"/></svg></button><button type="button" class="iconbtn" id="close" aria-label="<?php esc_attr_e( 'Close chat', 'leadbee' ); ?>"><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['close_icon'] ); ?>"/></svg></button></div>
    </header>
    <div class="welcome" id="welcome">
      <div class="welcome-kicker"><?php esc_html_e( "WE'RE HERE FOR YOU", 'leadbee' ); ?></div>
      <h2><?php echo nl2br( esc_html( $heading ) ); ?> <span class="wave"><?php echo esc_html( $welcome_icon ); ?></span></h2>
      <p><?php echo esc_html( $description ); ?></p>
      <div class="section-label"><?php esc_html_e( 'HOW CAN WE HELP YOU TODAY?', 'leadbee' ); ?></div><button type="button" class="primary" id="start"><span><?php esc_html_e( 'START CONVERSATION', 'leadbee' ); ?></span><svg class="ico"><use href="#ic-arrow"/></svg></button>
      <div class="contact">
        <?php if ( $show_whatsapp ) : ?><a class="contact-card" href="https://wa.me/<?php echo esc_attr( $whatsapp ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( sprintf( __( 'WhatsApp %s', 'leadbee' ), $business_name ) ); ?>"><?php if ( 'whatsapp' === $appearance['whatsapp_icon'] ) : ?><img class="contact-icon whatsapp-icon" src="<?php echo esc_url( LEADBEE_URL . 'public/assets/images/whatsapp.png' ); ?>" alt="" width="28" height="26" loading="lazy"><?php else : ?><svg class="ico whatsapp-icon"><use href="#ic-<?php echo esc_attr( $appearance['whatsapp_icon'] ); ?>"/></svg><?php endif; ?><span><?php esc_html_e( 'WHATSAPP', 'leadbee' ); ?></span></a><?php endif; ?>
        <?php if ( $show_email ) : ?><a class="contact-card" href="mailto:<?php echo esc_attr( $contacts['email'] ); ?>?subject=<?php echo rawurlencode( $business_name . ' Enquiry' ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Email %s', 'leadbee' ), $business_name ) ); ?>"><?php if ( 'mail' === $appearance['email_icon'] ) : ?><img class="contact-icon mail-icon" src="<?php echo esc_url( LEADBEE_URL . 'public/assets/images/mail.png' ); ?>" alt="" width="28" height="26" loading="lazy"><?php else : ?><svg class="ico mail-icon"><use href="#ic-<?php echo esc_attr( $appearance['email_icon'] ); ?>"/></svg><?php endif; ?><span><?php esc_html_e( 'EMAIL US', 'leadbee' ); ?></span></a><?php endif; ?>
      </div>
      <?php if ( $show_more ) : ?><details class="more-contacts"><summary><span><?php esc_html_e( 'MORE CONTACT OPTIONS', 'leadbee' ); ?></span><span class="chevron" aria-hidden="true">⌄</span></summary><div class="more-links">
        <?php if ( $show_call ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contacts['phone'] ) ); ?>"><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['phone_icon'] ); ?>"/></svg><span><?php echo esc_html( $contacts['call_label'] ? $contacts['call_label'] : sprintf( __( 'Call %s', 'leadbee' ), $contacts['phone'] ) ); ?></span></a><?php endif; ?>
        <?php if ( $show_additional_phone ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contacts['additional_phone'] ) ); ?>"><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['phone_icon'] ); ?>"/></svg><span><?php echo esc_html( $contacts['additional_phone_label'] ? $contacts['additional_phone_label'] : sprintf( __( 'Call %s', 'leadbee' ), $contacts['additional_phone'] ) ); ?></span></a><?php endif; ?>
        <?php if ( $show_additional_email ) : ?><a href="mailto:<?php echo esc_attr( $contacts['additional_email'] ); ?>"><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['email_icon'] ); ?>"/></svg><span><?php echo esc_html( $contacts['additional_email_label'] ? $contacts['additional_email_label'] : __( 'Email another contact', 'leadbee' ) ); ?></span></a><?php endif; ?>
        <?php if ( $show_website ) : ?><a href="<?php echo esc_url( $contacts['website'] ); ?>" target="_blank" rel="noopener noreferrer"><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['website_icon'] ); ?>"/></svg><span><?php echo esc_html( $contacts['website_label'] ? $contacts['website_label'] : __( 'Visit our website', 'leadbee' ) ); ?></span></a><?php endif; ?>
      </div></details><?php endif; ?>
      <?php if ( $privacy_url ) : ?><div class="privacy"><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['privacy_icon'] ); ?>"/></svg><span><?php esc_html_e( 'Your details are only shared with the team to respond to your enquiry.', 'leadbee' ); ?> <a href="<?php echo esc_url( $privacy_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Privacy information', 'leadbee' ); ?></a></span></div><?php endif; ?>
    </div>
    <div class="chat" id="chat" hidden>
      <div class="assistant-strip"><span class="sparkle">✧</span> <?php echo esc_html( $assistant_name ); ?> · <?php echo esc_html( $subtitle ); ?></div>
      <div class="messages" id="messages" role="log" aria-live="polite"></div>
      <div class="completed" id="completed" hidden><strong><?php esc_html_e( 'Enquiry received', 'leadbee' ); ?></strong><p><?php esc_html_e( 'Your confirmed enquiry has been saved. You can begin a fresh conversation below.', 'leadbee' ); ?></p><button type="button" id="newChatButton"><?php esc_html_e( 'START NEW CHAT', 'leadbee' ); ?><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['restart_icon'] ); ?>"/></svg></button></div>
      <div class="suggestions" id="suggestions"></div><div class="notice" id="notice" hidden></div><div class="status" id="status" aria-live="polite"></div>
      <form class="composer" id="form"><input id="input" autocomplete="off" maxlength="1000" required placeholder="<?php esc_attr_e( 'Type your message…', 'leadbee' ); ?>" aria-label="<?php esc_attr_e( 'Your message', 'leadbee' ); ?>"><button type="submit" id="send" class="send" aria-label="<?php esc_attr_e( 'Send message', 'leadbee' ); ?>"><?php esc_html_e( 'Send', 'leadbee' ); ?><svg class="ico"><use href="#ic-<?php echo esc_attr( $appearance['send_icon'] ); ?>"/></svg></button></form>
      <label class="leadbee-honeypot" aria-hidden="true">Website <input type="text" id="websiteField" name="company_website" tabindex="-1" autocomplete="off"></label><button type="button" class="request-link" id="requestLink" <?php echo empty( $general['lead_collection'] ) ? 'hidden' : ''; ?>><?php esc_html_e( 'Make an Enquiry', 'leadbee' ); ?></button>
    </div>
    <footer class="foot"><?php echo ! empty( $appearance['powered_by_enabled'] ) ? '<strong>' . esc_html( $footer ) . '</strong> · ' . esc_html__( 'Powered by LeadBee', 'leadbee' ) : '<strong>' . esc_html( $footer ) . '</strong>'; ?></footer>
  </section>
</div>
<?php
