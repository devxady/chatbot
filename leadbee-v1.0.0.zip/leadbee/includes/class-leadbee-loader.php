<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LeadBee_Loader {
	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function activate() {
		LeadBee_Database::install();
		LeadBee_Knowledge_Base::install_defaults();
		LeadBee_Admin::install_defaults();
		update_option( 'leadbee_version', LEADBEE_VERSION, false );
	}

	public static function deactivate() {
		// Deactivation preserves business data and clears only the housekeeping event.
		wp_clear_scheduled_hook( 'leadbee_daily_cleanup' );
	}

	private function __construct() {
		load_plugin_textdomain( 'leadbee', false, dirname( plugin_basename( LEADBEE_FILE ) ) . '/languages' );
		LeadBee_Database::maybe_upgrade();
		if ( ! wp_next_scheduled( 'leadbee_daily_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'leadbee_daily_cleanup' );
		}
		add_action( 'leadbee_daily_cleanup', array( 'LeadBee_Database', 'cleanup_expired' ) );
		new LeadBee_Rest_API();
		new LeadBee_Public();
		if ( is_admin() ) {
			new LeadBee_Admin();
		}
	}
}
