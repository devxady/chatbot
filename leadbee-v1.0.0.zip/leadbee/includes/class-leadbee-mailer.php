<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LeadBee_Mailer {
	private static $sending_leadbee = false;
	private static $last_error      = '';

	public static function init() {
		add_action( 'phpmailer_init', array( __CLASS__, 'configure_smtp' ), 20 );
		add_action( 'wp_mail_failed', array( __CLASS__, 'capture_error' ) );
	}

	public static function notify( $lead_id ) {
		$lead = LeadBee_Database::get( $lead_id );
		if ( ! $lead ) {
			return false;
		}
		$settings  = LeadBee_Admin::settings( 'email' );
		$recipient = sanitize_email( $settings['recipient'] );
		if ( ! $recipient || ! is_email( $recipient ) ) {
			$error = __( 'Set a valid notification recipient in LeadBee Email Settings.', 'leadbee' );
			LeadBee_Database::update_mail_status( $lead_id, 'failed', $error );
			self::save_last_status( 'failed', $error, '', $settings['method'] );
			return false;
		}
		$configuration_error = self::custom_smtp_error( $settings );
		if ( $configuration_error ) {
			LeadBee_Database::update_mail_status( $lead_id, 'failed', $configuration_error );
			self::save_last_status( 'failed', $configuration_error, $recipient, $settings['method'] );
			return false;
		}
		$kb       = LeadBee_Knowledge_Base::active();
		$business = isset( $kb['business_profile']['name'] ) ? $kb['business_profile']['name'] : 'Driving School';
		$subject  = str_replace( array( '{{lead_id}}', '{{name}}' ), array( $lead->lead_uuid, $lead->full_name ), $settings['subject'] );
		$subject  = sanitize_text_field( $subject );
		$headers  = array( 'Content-Type: text/html; charset=UTF-8' );
		$reply    = sanitize_email( $settings['reply_to'] );
		if ( is_email( $reply ) ) {
			$headers[] = 'Reply-To: ' . $reply;
		} elseif ( $lead->email && is_email( $lead->email ) ) {
			$headers[] = 'Reply-To: ' . $lead->email;
		}
		$cc = array_filter( array_map( 'sanitize_email', explode( ',', $settings['cc'] ) ), 'is_email' );
		foreach ( $cc as $address ) {
			$headers[] = 'Cc: ' . $address;
		}
		$message = self::render_email( $lead, $business );
		self::$last_error      = '';
		self::$sending_leadbee = true;
		$result                = false;
		try {
			$result = wp_mail( $recipient, $subject, $message, $headers );
		} catch ( Throwable $exception ) {
			self::$last_error = sanitize_text_field( $exception->getMessage() );
		} finally {
			self::$sending_leadbee = false;
		}
		if ( $result ) {
			LeadBee_Database::update_mail_status( $lead_id, 'sent' );
			self::save_last_status( 'sent', '', $recipient, $settings['method'] );
			return true;
		}
		$error = self::$last_error ? self::$last_error : __( 'WordPress could not deliver this notification.', 'leadbee' );
		LeadBee_Database::update_mail_status( $lead_id, 'failed', $error );
		self::save_last_status( 'failed', $error, $recipient, $settings['method'] );
		return false;
	}

	public static function configure_smtp( $mailer ) {
		if ( ! self::$sending_leadbee ) {
			return;
		}
		$settings = LeadBee_Admin::settings( 'email' );
		if ( 'custom' !== $settings['method'] || empty( $settings['smtp_host'] ) ) {
			return;
		}
		$password = LeadBee_Security::decrypt_secret( $settings['smtp_password'] );
		$mailer->isSMTP();
		$mailer->Host       = sanitize_text_field( $settings['smtp_host'] );
		$mailer->Port       = absint( $settings['smtp_port'] );
		$mailer->SMTPAuth   = ! empty( $settings['smtp_auth'] );
		$mailer->Username   = sanitize_text_field( $settings['smtp_username'] );
		$mailer->Password   = $password;
		$mailer->SMTPSecure = in_array( $settings['smtp_encryption'], array( 'ssl', 'tls' ), true ) ? $settings['smtp_encryption'] : '';
		$mailer->Timeout    = 15;
		$mailer->SMTPAutoTLS = 'tls' === $settings['smtp_encryption'];
		$from = sanitize_email( $settings['from_email'] );
		$from = is_email( $from ) ? $from : get_option( 'admin_email' );
		$mailer->setFrom( $from, sanitize_text_field( $settings['from_name'] ? $settings['from_name'] : get_bloginfo( 'name' ) ), false );
	}

	public static function capture_error( $error ) {
		if ( self::$sending_leadbee && is_wp_error( $error ) ) {
			$message = sanitize_text_field( $error->get_error_message() );
			$secret  = LeadBee_Security::decrypt_secret( LeadBee_Admin::settings( 'email' )['smtp_password'] );
			if ( $secret ) { $message = str_replace( $secret, '[redacted]', $message ); }
			self::$last_error = substr( $message, 0, 500 );
		}
	}

	public static function test_email() {
		$settings = LeadBee_Admin::settings( 'email' );
		$to       = sanitize_email( $settings['recipient'] );
		if ( ! is_email( $to ) ) {
			$error = __( 'Enter a valid admin recipient email first.', 'leadbee' );
			self::save_last_status( 'failed', $error, '', $settings['method'] );
			return new WP_Error( 'leadbee_email_recipient', $error );
		}
		$configuration_error = self::custom_smtp_error( $settings );
		if ( $configuration_error ) {
			self::save_last_status( 'failed', $configuration_error, $to, $settings['method'] );
			return new WP_Error( 'leadbee_smtp_configuration', $configuration_error );
		}
		self::$last_error      = '';
		self::$sending_leadbee = true;
		$sent                  = false;
		try {
			$sent = wp_mail( $to, __( 'LeadBee test email', 'leadbee' ), '<p>' . esc_html__( 'LeadBee can send email through the selected delivery method.', 'leadbee' ) . '</p>', array( 'Content-Type: text/html; charset=UTF-8' ) );
		} catch ( Throwable $exception ) {
			self::$last_error = sanitize_text_field( $exception->getMessage() );
		} finally {
			self::$sending_leadbee = false;
		}
		if ( ! $sent ) {
			$error = self::$last_error ? self::$last_error : __( 'Test email could not be sent. Check the email settings.', 'leadbee' );
		self::save_last_status( 'failed', $error, $to, $settings['method'] );
			return new WP_Error( 'leadbee_email_test_failed', $error );
		}
		self::save_last_status( 'test_sent', '', $to, $settings['method'] );
		return true;
	}

	private static function custom_smtp_error( $settings ) {
		if ( 'custom' !== $settings['method'] ) {
			return '';
		}
		if ( '' === trim( $settings['smtp_host'] ) ) {
			return __( 'Enter an SMTP host before using LeadBee custom SMTP.', 'leadbee' );
		}
		if ( ! empty( $settings['smtp_auth'] ) && ( '' === trim( $settings['smtp_username'] ) || '' === LeadBee_Security::decrypt_secret( $settings['smtp_password'] ) ) ) {
			return __( 'SMTP authentication is enabled, but a username or saved password is missing.', 'leadbee' );
		}
		return '';
	}

	private static function save_last_status( $status, $error, $recipient = '', $method = '' ) {
		update_option( 'leadbee_last_email_status', array( 'status' => sanitize_key( $status ), 'error' => sanitize_text_field( $error ), 'recipient' => sanitize_email( $recipient ), 'method' => sanitize_key( $method ), 'time' => current_time( 'mysql' ) ), false );
	}

	private static function render_email( $lead, $business ) {
		$transcript = json_decode( $lead->transcript, true );
		$lines      = '';
		if ( is_array( $transcript ) ) {
			foreach ( $transcript as $message ) {
				$label  = 'user' === $message['role'] ? __( 'Visitor', 'leadbee' ) : __( 'Assistant', 'leadbee' );
				$lines .= '<p style="margin:0 0 8px"><strong>' . esc_html( $label ) . ':</strong> ' . nl2br( esc_html( $message['text'] ) ) . '</p>';
			}
		}
		$admin_url = add_query_arg( array( 'page' => 'leadbee-leads', 'view' => 'detail', 'id' => $lead->id ), admin_url( 'admin.php' ) );
		$rows      = array(
			__( 'Lead ID', 'leadbee' )                => $lead->lead_uuid,
			__( 'Name', 'leadbee' )                   => $lead->full_name,
			__( 'Phone', 'leadbee' )                  => $lead->phone,
			__( 'Email', 'leadbee' )                  => $lead->email ? $lead->email : __( 'Not provided', 'leadbee' ),
			__( 'Address / postcode', 'leadbee' )      => $lead->address,
			__( 'Lesson type', 'leadbee' )             => $lead->lesson_type,
			__( 'Preferred availability', 'leadbee' )  => $lead->availability,
			__( 'Additional requirements', 'leadbee' ) => $lead->additional_requirements ? $lead->additional_requirements : __( 'None supplied', 'leadbee' ),
			__( 'Submitted', 'leadbee' )               => get_date_from_gmt( $lead->created_at, 'j M Y, H:i' ),
		);
		$html = '<div style="margin:0 auto;max-width:680px;font-family:Arial,sans-serif;color:#20242b"><div style="padding:22px;background:#ffda17;border-radius:12px 12px 0 0"><h1 style="margin:0;font-size:22px">' . esc_html( $business ) . ' enquiry</h1></div><div style="padding:22px;border:1px solid #e7eaf0;border-top:0">';
		foreach ( $rows as $label => $value ) {
			$html .= '<p style="margin:0 0 10px"><strong>' . esc_html( $label ) . ':</strong> ' . nl2br( esc_html( $value ) ) . '</p>';
		}
		$html .= '<h2 style="font-size:17px;margin-top:26px">' . esc_html__( 'Conversation transcript', 'leadbee' ) . '</h2><div style="padding:14px;background:#f5f6f8;border-radius:8px">' . $lines . '</div><p style="margin-top:24px"><a style="display:inline-block;padding:12px 16px;border-radius:8px;background:#ffda17;color:#171b24;text-decoration:none;font-weight:bold" href="' . esc_url( $admin_url ) . '">' . esc_html__( 'View lead in WordPress', 'leadbee' ) . '</a></p></div></div>';
		return $html;
	}
}

LeadBee_Mailer::init();
