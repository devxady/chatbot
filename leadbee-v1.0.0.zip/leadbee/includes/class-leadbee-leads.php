<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LeadBee_Leads {
	public static function save( $payload, $request ) {
		if ( empty( $payload['consent'] ) || empty( $payload['confirmed'] ) ) {
			return new WP_Error( 'leadbee_confirmation_required', __( 'Your enquiry needs your consent and explicit confirmation before it can be saved.', 'leadbee' ), array( 'status' => 400 ) );
		}
		$required = array( 'lesson_type', 'availability', 'name', 'phone', 'address' );
		foreach ( $required as $key ) {
			if ( empty( $payload[ $key ] ) ) {
				return new WP_Error( 'leadbee_missing_field', __( 'Please complete each required enquiry detail.', 'leadbee' ), array( 'status' => 400 ) );
			}
		}
		$name         = sanitize_text_field( $payload['name'] );
		$raw_email    = isset( $payload['email'] ) ? sanitize_text_field( $payload['email'] ) : '';
		$email        = $raw_email ? sanitize_email( $raw_email ) : '';
		$phone        = sanitize_text_field( $payload['phone'] );
		$address      = sanitize_text_field( $payload['address'] );
		$availability = sanitize_text_field( $payload['availability'] );
		$lesson_type  = strtolower( sanitize_text_field( $payload['lesson_type'] ) );
		if ( ! preg_match( '/^[\p{L}][\p{L}\p{M}\' .-]{2,99}$/u', $name ) || count( preg_split( '/\s+/', trim( $name ) ) ) < 2 ) {
			return new WP_Error( 'leadbee_invalid_name', __( 'Please enter your first name and surname.', 'leadbee' ), array( 'status' => 400 ) );
		}
		if ( ! in_array( $lesson_type, array( 'manual', 'automatic' ), true ) || strlen( $availability ) < 3 || strlen( $availability ) > 180 || strlen( $address ) < 4 || strlen( $address ) > 240 ) {
			return new WP_Error( 'leadbee_invalid_details', __( 'One or more enquiry details are invalid. Please review them and try again.', 'leadbee' ), array( 'status' => 400 ) );
		}
		if ( ! LeadBee_Security::valid_uk_phone( $phone ) ) {
			return new WP_Error( 'leadbee_invalid_phone', __( 'Please provide a valid UK phone number.', 'leadbee' ), array( 'status' => 400 ) );
		}
		if ( $raw_email && ( ! $email || ! is_email( $email ) || strlen( $email ) > 190 ) ) {
			return new WP_Error( 'leadbee_invalid_email', __( 'Please check the optional email address.', 'leadbee' ), array( 'status' => 400 ) );
		}
		$idempotency = isset( $payload['idempotency_key'] ) ? preg_replace( '/[^a-zA-Z0-9_-]/', '', $payload['idempotency_key'] ) : '';
		if ( strlen( $idempotency ) < 16 || strlen( $idempotency ) > 64 ) {
			return new WP_Error( 'leadbee_invalid_request', __( 'Please refresh the chat and confirm your enquiry again.', 'leadbee' ), array( 'status' => 400 ) );
		}
		$transcript = LeadBee_Security::clean_transcript( isset( $payload['transcript'] ) ? $payload['transcript'] : array() );
		if ( empty( $transcript ) ) {
			return new WP_Error( 'leadbee_missing_transcript', __( 'The conversation could not be verified. Please restart the chat and try again.', 'leadbee' ), array( 'status' => 400 ) );
		}
		$has_explicit_confirmation = false;
		foreach ( $transcript as $message ) {
			if ( 'user' === $message['role'] && preg_match( '/^(confirm details|confirm|yes all correct|everything is correct|correct)$/i', trim( $message['text'] ) ) ) {
				$has_explicit_confirmation = true;
				break;
			}
		}
		if ( ! $has_explicit_confirmation ) {
			return new WP_Error( 'leadbee_confirmation_required', __( 'The conversation does not include an explicit confirmation of the enquiry details.', 'leadbee' ), array( 'status' => 400 ) );
		}
		$additional = isset( $payload['additional_requirements'] ) ? sanitize_textarea_field( $payload['additional_requirements'] ) : '';
		$remote      = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$saved = LeadBee_Database::insert_lead(
			array(
				'idempotency_key'         => $idempotency,
				'name'                    => $name,
				'email'                   => $email,
				'phone'                   => $phone,
				'address'                 => $address,
				'lesson_type'             => ucfirst( $lesson_type ),
				'availability'            => $availability,
				'additional_requirements' => function_exists( 'mb_substr' ) ? mb_substr( $additional, 0, 1000 ) : substr( $additional, 0, 1000 ),
				'transcript'              => $transcript,
				'remote_hash'             => $remote ? hash_hmac( 'sha256', $remote, wp_salt( 'nonce' ) ) : '',
			)
		);
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		if ( ! $saved['duplicate'] ) {
			$settings = LeadBee_Admin::settings( 'general' );
			if ( ! empty( $settings['notifications_enabled'] ) ) {
				LeadBee_Mailer::notify( $saved['id'] );
			} else {
				LeadBee_Database::update_mail_status( $saved['id'], 'disabled' );
			}
		}
		return $saved;
	}
}
