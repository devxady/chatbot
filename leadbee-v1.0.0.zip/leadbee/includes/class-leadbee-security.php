<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LeadBee_Security {
	public static function clean_transcript( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}
		$out = array();
		foreach ( array_slice( $value, 0, 400 ) as $message ) {
			if ( ! is_array( $message ) || empty( $message['role'] ) ) {
				continue;
			}
			$role = in_array( $message['role'], array( 'user', 'bot' ), true ) ? $message['role'] : 'bot';
			$text = isset( $message['text'] ) ? sanitize_textarea_field( wp_unslash( $message['text'] ) ) : '';
			$text = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, 2000 ) : substr( $text, 0, 2000 );
			if ( '' !== $text ) {
				$out[] = array( 'role' => $role, 'text' => $text );
			}
		}
		return $out;
	}

	public static function valid_uk_phone( $phone ) {
		$raw    = trim( (string) $phone );
		$digits = preg_replace( '/\D+/', '', $raw );
		if ( 0 === strpos( $digits, '0044' ) ) {
			$digits = substr( $digits, 4 );
			if ( 0 === strpos( $digits, '0' ) ) { return false; }
		} elseif ( 0 === strpos( $digits, '44' ) && ( '+' === substr( $raw, 0, 1 ) || strlen( $digits ) > 11 ) ) {
			$digits = substr( $digits, 2 );
			if ( 0 === strpos( $digits, '0' ) ) { return false; }
		} elseif ( 0 !== strpos( $digits, '0' ) || 11 !== strlen( $digits ) ) {
			return false;
		}
		if ( 11 === strlen( $digits ) && '0' === $digits[0] ) {
			$digits = substr( $digits, 1 );
		}
		return 10 === strlen( $digits ) && (bool) preg_match( '/^[1237]\d{9}$/', $digits );
	}

	public static function encrypt_secret( $plain ) {
		if ( '' === $plain ) {
			return '';
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return new WP_Error( 'leadbee_crypto_unavailable', __( 'This server does not provide OpenSSL, so the SMTP password cannot be stored securely.', 'leadbee' ) );
		}
		$iv        = random_bytes( 16 );
		$key       = hash( 'sha256', wp_salt( 'auth' ), true );
		$cipher    = openssl_encrypt( $plain, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv );
		$signature = hash_hmac( 'sha256', $iv . $cipher, $key, true );
		return base64_encode( $iv . $signature . $cipher );
	}

	public static function decrypt_secret( $stored ) {
		if ( ! $stored || ! function_exists( 'openssl_decrypt' ) ) {
			return '';
		}
		$raw = base64_decode( $stored, true );
		if ( false === $raw || strlen( $raw ) < 48 ) {
			return '';
		}
		$iv        = substr( $raw, 0, 16 );
		$signature = substr( $raw, 16, 32 );
		$cipher    = substr( $raw, 48 );
		$key       = hash( 'sha256', wp_salt( 'auth' ), true );
		if ( ! hash_equals( $signature, hash_hmac( 'sha256', $iv . $cipher, $key, true ) ) ) {
			return '';
		}
		$plain = openssl_decrypt( $cipher, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv );
		return false === $plain ? '' : $plain;
	}
}
