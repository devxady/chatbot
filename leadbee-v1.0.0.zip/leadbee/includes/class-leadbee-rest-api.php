<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LeadBee_Rest_API {
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			'leadbee/v1',
			'/leads',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'submit_lead' ),
				'permission_callback' => array( $this, 'allow_submission' ),
				'args'                => array(),
			)
		);
	}

	public function allow_submission( $request ) {
		$nonce = $request->get_header( 'x-wp-nonce' );
		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new WP_Error( 'leadbee_invalid_nonce', __( 'The chat session has expired. Refresh the page and try again.', 'leadbee' ), array( 'status' => 403 ) );
		}
		$origin = $request->get_header( 'origin' );
		if ( $origin ) {
			$origin_host = wp_parse_url( $origin, PHP_URL_HOST );
			$site_host   = wp_parse_url( home_url(), PHP_URL_HOST );
			if ( ! $origin_host || ! $site_host || strtolower( $origin_host ) !== strtolower( $site_host ) ) {
				return new WP_Error( 'leadbee_invalid_origin', __( 'The enquiry could not be accepted from this website.', 'leadbee' ), array( 'status' => 403 ) );
			}
		}
		return true;
	}

	public function submit_lead( $request ) {
		$general = LeadBee_Admin::settings( 'general' );
		if ( empty( $general['enabled'] ) || empty( $general['lead_collection'] ) ) {
			return new WP_Error( 'leadbee_disabled', __( 'Enquiry submission is currently unavailable.', 'leadbee' ), array( 'status' => 503 ) );
		}
		$honeypot = $request->get_param( 'company_website' );
		if ( ! empty( $honeypot ) ) {
			return new WP_Error( 'leadbee_spam', __( 'The enquiry could not be accepted.', 'leadbee' ), array( 'status' => 400 ) );
		}
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		$key    = 'leadbee_rate_' . hash_hmac( 'sha256', $remote, wp_salt( 'nonce' ) );
		$count  = (int) get_transient( $key );
		if ( $count >= 8 ) {
			return new WP_Error( 'leadbee_rate_limited', __( 'Please wait a little before sending another enquiry.', 'leadbee' ), array( 'status' => 429 ) );
		}
		set_transient( $key, $count + 1, HOUR_IN_SECONDS );
		$payload = $request->get_json_params();
		if ( ! is_array( $payload ) ) {
			return new WP_Error( 'leadbee_invalid_request', __( 'The enquiry could not be read. Please try again.', 'leadbee' ), array( 'status' => 400 ) );
		}
		$saved = LeadBee_Leads::save( $payload, $request );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		return rest_ensure_response( array( 'success' => true, 'lead_id' => $saved['lead_uuid'] ) );
	}
}
