<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LeadBee_Database {
	const SCHEMA_VERSION = '1.0.0';

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'leadbee_leads';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table           = self::table();
		$charset_collate = $wpdb->get_charset_collate();
		$sql             = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			lead_uuid varchar(40) NOT NULL,
			idempotency_key varchar(64) NOT NULL,
			full_name varchar(100) NOT NULL,
			email varchar(190) NOT NULL DEFAULT '',
			phone varchar(32) NOT NULL,
			address varchar(240) NOT NULL,
			lesson_type varchar(16) NOT NULL,
			availability varchar(180) NOT NULL,
			additional_requirements text NOT NULL,
			transcript longtext NOT NULL,
			created_at datetime NOT NULL,
			status varchar(24) NOT NULL DEFAULT 'new',
			email_status varchar(24) NOT NULL DEFAULT 'pending',
			email_error text NOT NULL,
			admin_notes longtext NOT NULL,
			remote_hash char(64) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			UNIQUE KEY lead_uuid (lead_uuid),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY status (status),
			KEY created_at (created_at),
			KEY lesson_type (lesson_type)
		) {$charset_collate};";
		dbDelta( $sql );
		update_option( 'leadbee_db_version', self::SCHEMA_VERSION, false );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'leadbee_db_version' ) !== self::SCHEMA_VERSION ) {
			self::install();
		}
	}

	public static function insert_lead( $data ) {
		global $wpdb;
		$table = self::table();
		$now   = current_time( 'mysql', true );
		$uuid  = 'LB-' . strtoupper( substr( str_replace( '-', '', wp_generate_uuid4() ), 0, 12 ) );
		$ok    = $wpdb->insert(
			$table,
			array(
				'lead_uuid'                 => $uuid,
				'idempotency_key'           => $data['idempotency_key'],
				'full_name'                 => $data['name'],
				'email'                     => $data['email'],
				'phone'                     => $data['phone'],
				'address'                   => $data['address'],
				'lesson_type'               => $data['lesson_type'],
				'availability'              => $data['availability'],
				'additional_requirements'   => $data['additional_requirements'],
				'transcript'                => wp_json_encode( $data['transcript'] ),
				'created_at'                => $now,
				'status'                    => 'new',
				'email_status'              => 'pending',
				'email_error'               => '',
				'admin_notes'               => '',
				'remote_hash'               => $data['remote_hash'],
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $ok ) {
			$existing = self::get_by_idempotency( $data['idempotency_key'] );
			if ( $existing ) {
				return array( 'id' => (int) $existing->id, 'lead_uuid' => $existing->lead_uuid, 'duplicate' => true );
			}
			return new WP_Error( 'leadbee_database_error', __( 'Your enquiry could not be saved. Please try again.', 'leadbee' ), array( 'status' => 500 ) );
		}
		return array( 'id' => (int) $wpdb->insert_id, 'lead_uuid' => $uuid, 'duplicate' => false );
	}

	public static function get_by_idempotency( $key ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE idempotency_key = %s LIMIT 1', $key ) );
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d LIMIT 1', absint( $id ) ) );
	}

	public static function update_mail_status( $id, $status, $error = '' ) {
		global $wpdb;
		$wpdb->update( self::table(), array( 'email_status' => $status, 'email_error' => $error ), array( 'id' => absint( $id ) ), array( '%s', '%s' ), array( '%d' ) );
	}

	public static function statuses() {
		return array( 'new', 'contacted', 'in_progress', 'converted', 'closed' );
	}

	public static function cleanup_expired() {
		$settings = LeadBee_Admin::settings( 'general' );
		$days     = isset( $settings['retention_days'] ) ? absint( $settings['retention_days'] ) : 0;
		if ( ! $days ) {
			return;
		}
		global $wpdb;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( DAY_IN_SECONDS * $days ) );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE created_at < %s', $cutoff ) );
	}

	public static function delete_all_data() {
		global $wpdb;
		$table = self::table();
		$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" );
		foreach ( array( 'leadbee_version', 'leadbee_db_version', 'leadbee_knowledge_base', 'leadbee_knowledge_base_backups', 'leadbee_knowledge_base_updated', 'leadbee_appearance', 'leadbee_contacts', 'leadbee_general', 'leadbee_email', 'leadbee_last_email_status' ) as $option ) {
			delete_option( $option );
		}
		$prefixes = array( '_transient_leadbee_', '_transient_timeout_leadbee_' );
		foreach ( $prefixes as $prefix ) {
			$like  = $wpdb->esc_like( $prefix ) . '%';
			$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) );
			foreach ( $names as $name ) {
				delete_option( $name );
			}
		}
		wp_clear_scheduled_hook( 'leadbee_daily_cleanup' );
	}
}
