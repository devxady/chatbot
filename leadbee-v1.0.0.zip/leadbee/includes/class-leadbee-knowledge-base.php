<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LeadBee_Knowledge_Base {
	public static function default_path() {
		return LEADBEE_PATH . 'data/default-knowledge-base.json';
	}

	public static function read_default() {
		$raw = file_get_contents( self::default_path() );
		return $raw ? json_decode( $raw, true ) : null;
	}

	public static function install_defaults() {
		if ( false === get_option( 'leadbee_knowledge_base', false ) ) {
			$kb = self::read_default();
			if ( is_array( $kb ) ) {
				update_option( 'leadbee_knowledge_base', $kb, false );
			}
		}
	}

	public static function active() {
		$kb = get_option( 'leadbee_knowledge_base', array() );
		return is_array( $kb ) && self::validate( $kb )['valid'] ? $kb : self::read_default();
	}

	public static function validate( $data ) {
		$errors = array();
		foreach ( array( 'schema_version', 'chatbot_policy', 'conversation_routing', 'lead_capture', 'fallbacks', 'business_profile', 'qa' ) as $key ) {
			if ( ! array_key_exists( $key, $data ) ) {
				$errors[] = sprintf( __( 'Required section "%s" is missing.', 'leadbee' ), $key );
			}
		}
		if ( ! isset( $data['schema_version'] ) || ! is_string( $data['schema_version'] ) || ! preg_match( '/^1\.\d+\.\d+$/', $data['schema_version'] ) ) {
			$errors[] = __( 'schema_version must be a supported 1.x.y version string.', 'leadbee' );
		}
		foreach ( array( 'chatbot_policy', 'conversation_routing', 'lead_capture', 'fallbacks', 'business_profile' ) as $key ) {
			if ( isset( $data[ $key ] ) && ! is_array( $data[ $key ] ) ) {
				$errors[] = sprintf( __( 'Section "%s" must be an object.', 'leadbee' ), $key );
			}
		}
		if ( isset( $data['qa'] ) && ! is_array( $data['qa'] ) ) {
			$errors[] = __( 'qa must be an array.', 'leadbee' );
		} elseif ( isset( $data['qa'] ) && empty( $data['qa'] ) ) {
			$errors[] = __( 'qa must contain at least one question and answer.', 'leadbee' );
		} elseif ( isset( $data['qa'] ) ) {
			foreach ( $data['qa'] as $index => $item ) {
				$questions_valid = is_array( $item ) && ! empty( $item['questions'] ) && is_array( $item['questions'] );
				if ( $questions_valid ) {
					foreach ( $item['questions'] as $question ) { if ( ! is_string( $question ) || '' === trim( $question ) ) { $questions_valid = false; break; } }
				}
				if ( ! is_array( $item ) || empty( $item['answer'] ) || ! is_string( $item['answer'] ) || ! $questions_valid ) {
					$errors[] = sprintf( __( 'Q&A record %d needs a questions array and an answer string.', 'leadbee' ), $index + 1 );
					if ( count( $errors ) > 20 ) {
						break;
					}
				}
			}
		}
		if ( ! isset( $data['lead_capture']['fields'] ) || ! is_array( $data['lead_capture']['fields'] ) ) {
			$errors[] = __( 'lead_capture.fields must be an array.', 'leadbee' );
		} elseif ( isset( $data['lead_capture'] ) ) {
			$field_keys = array();
			foreach ( $data['lead_capture']['fields'] as $field ) {
				if ( ! is_array( $field ) || empty( $field['key'] ) || ! is_string( $field['key'] ) || empty( $field['ask'] ) || ! is_string( $field['ask'] ) || ! isset( $field['required'] ) || ! is_bool( $field['required'] ) ) {
					$errors[] = __( 'Each lead field needs a key, ask string and required boolean.', 'leadbee' );
					break;
				}
				$field_keys[] = $field['key'];
			}
			$required_keys = array( 'lesson_type', 'availability', 'name', 'phone', 'address' );
			if ( $field_keys !== $required_keys ) {
				$errors[] = __( 'lead_capture.fields must include exactly the required lesson type, availability, name, phone and address fields in order.', 'leadbee' );
			}
			foreach ( array( 'consent_prompt', 'confirmation_template' ) as $key ) {
				if ( empty( $data['lead_capture'][ $key ] ) || ! is_string( $data['lead_capture'][ $key ] ) ) { $errors[] = sprintf( __( 'lead_capture.%s must be a string.', 'leadbee' ), $key ); }
			}
			if ( empty( $data['lead_capture']['confirmation_buttons'] ) || ! is_array( $data['lead_capture']['confirmation_buttons'] ) ) {
				$errors[] = __( 'lead_capture.confirmation_buttons must be an array.', 'leadbee' );
			}
		}
		if ( isset( $data['conversation_routing'] ) && ( empty( $data['conversation_routing']['abbreviation_expansions'] ) || ! is_array( $data['conversation_routing']['abbreviation_expansions'] ) ) ) {
			$errors[] = __( 'conversation_routing.abbreviation_expansions must be an object.', 'leadbee' );
		}
		if ( isset( $data['conversation_routing']['abbreviation_expansions'] ) && is_array( $data['conversation_routing']['abbreviation_expansions'] ) ) {
			foreach ( $data['conversation_routing']['abbreviation_expansions'] as $from => $to ) {
				if ( ! is_string( $from ) || ! is_string( $to ) ) { $errors[] = __( 'Abbreviation expansions must contain string keys and values.', 'leadbee' ); break; }
			}
		}
		if ( isset( $data['fallbacks'] ) ) {
			foreach ( array( 'unclear', 'off_topic', 'gibberish' ) as $key ) {
				if ( empty( $data['fallbacks'][ $key ] ) || ! is_array( $data['fallbacks'][ $key ] ) ) {
					$errors[] = sprintf( __( 'fallbacks.%s must be an array.', 'leadbee' ), $key );
				}
			}
		}
		return array( 'valid' => empty( $errors ), 'errors' => $errors, 'qa_count' => isset( $data['qa'] ) && is_array( $data['qa'] ) ? count( $data['qa'] ) : 0 );
	}
}
