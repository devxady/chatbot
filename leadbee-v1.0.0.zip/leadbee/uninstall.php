<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$settings = get_option( 'leadbee_general', array() );
if ( empty( $settings['delete_data_on_uninstall'] ) ) {
	return;
}

global $wpdb;
$table = $wpdb->prefix . 'leadbee_leads';
$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" );

foreach ( array( 'leadbee_version', 'leadbee_db_version', 'leadbee_knowledge_base', 'leadbee_knowledge_base_backups', 'leadbee_knowledge_base_updated', 'leadbee_appearance', 'leadbee_contacts', 'leadbee_general', 'leadbee_email', 'leadbee_last_email_status' ) as $option ) {
	delete_option( $option );
}

$patterns = array( '_transient_leadbee_%', '_transient_timeout_leadbee_%' );
foreach ( $patterns as $pattern ) {
	$like = $wpdb->esc_like( str_replace( '%', '', $pattern ) ) . '%';
	$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) );
	foreach ( $names as $name ) {
		delete_option( $name );
	}
}
