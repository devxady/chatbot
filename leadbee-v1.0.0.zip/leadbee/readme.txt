=== LeadBee ===
Contributors: devxady
Tags: chatbot, leads, contact, driving school
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Customisable conversational chatbot and lead management plugin.

== Description ==

LeadBee adds a configurable Yello Driving School chatbot with an editable JSON knowledge base, confirmed lead submissions, private lead management, and WordPress email notifications.

The chatbot is rule-based and does not call a paid AI API. Visitors must explicitly confirm an enquiry before it is saved. Email is optional.

== Installation ==

1. Upload the plugin ZIP through Plugins > Add New Plugin > Upload Plugin.
2. Activate LeadBee.
3. Set current contact details, email delivery, and visibility under LeadBee settings.
4. Test an enquiry on a staging site before launch.

== Frequently Asked Questions ==

= Is email required? =

No. Visitors can provide it voluntarily.

= Does deactivation delete leads? =

When you click Deactivate, LeadBee asks whether to preserve or permanently delete its leads, transcripts, settings and knowledge base. Uninstall preserves data by default; deletion can be enabled in General Settings.

= Does LeadBee use generative AI? =

No. It uses the supplied JSON knowledge base and local rule-based matching.

== Changelog ==

= 1.0.0 =
* First installable release with the Yello chatbot, WordPress lead storage, admin lead tools, configurable settings, JSON knowledge-base management, and email notifications.
