<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LeadBee_Admin {
	private $pages = array(
		'leadbee-dashboard'       => 'Dashboard',
		'leadbee-leads'           => 'Leads',
		'leadbee-knowledge-base'  => 'Knowledge Base',
		'leadbee-appearance'      => 'Appearance',
		'leadbee-contact-settings'=> 'Contact Settings',
		'leadbee-email-settings'  => 'Email Settings',
		'leadbee-general-settings'=> 'General Settings',
		'leadbee-help'            => 'Help & Documentation',
	);

	public static function defaults() {
		$kb      = LeadBee_Knowledge_Base::read_default();
		$profile = is_array( $kb ) && isset( $kb['business_profile'] ) ? $kb['business_profile'] : array();
		return array(
			'appearance' => array(
				'display_name' => isset( $profile['assistant_name'] ) ? $profile['assistant_name'] : 'Yello Assistant',
				'assistant_name' => isset( $profile['assistant_name'] ) ? $profile['assistant_name'] : 'Yello Assistant',
				'welcome_heading' => "Welcome to Yello\nDriving School!",
				'welcome_icon' => '👋',
				'welcome_description' => "Ready to get behind the wheel? We're here to make learning to drive feel simple. Explore lesson enquiries, ask questions and get in touch — all in one place.",
				'header_subtitle' => 'Here to guide your journey',
				'status_text' => 'HERE TO HELP',
				'footer_text' => 'Yello Driving School · Automated replies',
				'powered_by_enabled' => 0,
				'avatar_url' => '',
				'primary_color' => '#ffda17', 'secondary_color' => '#171b24', 'accent_color' => '#c99700',
				'header_background' => '#ffffff', 'welcome_background' => '#ffffff', 'conversation_background' => '#ffffff',
				'user_bubble' => '#ffda17', 'bot_bubble' => '#f1f3f7', 'user_text' => '#171b24', 'bot_text' => '#171b24',
				'button_background' => '#ffda17', 'button_text' => '#171b24', 'secondary_button_background' => '#f4f6f9',
				'secondary_button_text' => '#171b24', 'input_background' => '#ffffff', 'input_border' => '#e2e7ef',
				'footer_background' => '#ffffff', 'status_color' => '#13b980', 'link_color' => '#52657c', 'hover_color' => '#fff9db',
				'text_color' => '#171b24', 'muted_color' => '#8390a7', 'border_color' => '#e8ebf0', 'soft_color' => '#f4f6f9',
				'font_family' => 'Plus Jakarta Sans', 'base_font_size' => 13, 'heading_font_size' => 29,
				'font_weight' => 800, 'button_font_weight' => 800, 'line_height' => '1.8',
				'panel_width' => 412, 'panel_height' => 666, 'desktop_position' => 'right', 'mobile_position' => 'bottom',
				'bottom_offset' => 23, 'right_offset' => 25, 'border_radius' => 25, 'shadow_intensity' => 19, 'launcher_size' => 70,
				'animations' => 1, 'typing_indicator' => 1, 'typing_min' => 750, 'typing_max' => 1450,
				'button_hover' => 1, 'launcher_pulse' => 0, 'window_animation' => 1, 'avatar_icon' => 'chat',
				'send_icon' => 'arrow', 'back_icon' => 'back', 'close_icon' => 'close', 'restart_icon' => 'restart',
				'whatsapp_icon' => 'whatsapp', 'email_icon' => 'mail', 'phone_icon' => 'phone', 'website_icon' => 'web', 'privacy_icon' => 'shield',
			),
			'contacts' => array(
				'business_name' => isset( $profile['name'] ) ? $profile['name'] : 'Yello Driving School',
				'email' => '', 'phone' => '', 'whatsapp' => '', 'website' => isset( $profile['website'] ) ? $profile['website'] : '',
				'additional_phone' => '', 'additional_email' => '', 'additional_phone_label' => '', 'additional_email_label' => '', 'privacy_url' => '',
				'whatsapp_enabled' => 1, 'email_enabled' => 1, 'call_enabled' => 1, 'website_enabled' => 1, 'more_enabled' => 1,
				'call_label' => '', 'website_label' => '',
			),
			'general' => array(
				'enabled' => 1, 'display_rule' => 'all', 'page_ids' => '', 'show_desktop' => 1, 'show_tablet' => 1, 'show_mobile' => 1,
				'launcher_text_enabled' => 1, 'launcher_text' => "Have a question? Let's chat 👋", 'launcher_icon' => 'chat',
				'lead_collection' => 1, 'notifications_enabled' => 1, 'session_persistence' => 1, 'suggestions' => 1,
				'max_suggestions' => 6, 'small_talk' => 1, 'match_sensitivity' => 73, 'greeting' => 'Hi there! 👋 Ask me a question about driving lessons, or request a callback from our team.',
				'fallback_behaviour' => 'friendly', 'debug_mode' => 0, 'retention_days' => 0, 'delete_data_on_uninstall' => 0,
			),
			'email' => array(
				'method' => 'wordpress', 'recipient' => get_option( 'admin_email' ), 'cc' => '', 'subject' => 'New driving lesson enquiry {{lead_id}}',
				'from_name' => isset( $profile['name'] ) ? $profile['name'] : 'Yello Driving School',
				'from_email' => get_option( 'admin_email' ), 'reply_to' => '', 'smtp_host' => '', 'smtp_port' => 587,
				'smtp_encryption' => 'tls', 'smtp_auth' => 1, 'smtp_username' => '', 'smtp_password' => '',
			),
		);
	}

	public static function install_defaults() {
		foreach ( self::defaults() as $section => $values ) {
			if ( false === get_option( 'leadbee_' . $section, false ) ) {
				add_option( 'leadbee_' . $section, $values, '', false );
			}
		}
	}

	public static function settings( $section ) {
		$defaults = self::defaults();
		$stored   = get_option( 'leadbee_' . $section, array() );
		return isset( $defaults[ $section ] ) ? array_merge( $defaults[ $section ], is_array( $stored ) ? $stored : array() ) : array();
	}

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_post_leadbee_lead_update', array( $this, 'handle_lead_update' ) );
		add_action( 'admin_post_leadbee_lead_delete', array( $this, 'handle_lead_delete' ) );
		add_action( 'admin_post_leadbee_export', array( $this, 'handle_export' ) );
		add_action( 'admin_post_leadbee_kb_import', array( $this, 'handle_kb_import' ) );
		add_action( 'admin_post_leadbee_kb_confirm', array( $this, 'handle_kb_confirm' ) );
		add_action( 'admin_post_leadbee_kb_cancel', array( $this, 'handle_kb_cancel' ) );
		add_action( 'admin_post_leadbee_kb_restore', array( $this, 'handle_kb_restore' ) );
		add_action( 'admin_post_leadbee_kb_rollback', array( $this, 'handle_kb_rollback' ) );
		add_action( 'admin_post_leadbee_kb_export', array( $this, 'handle_kb_export' ) );
		add_action( 'admin_post_leadbee_email_test', array( $this, 'handle_email_test' ) );
		add_action( 'admin_post_leadbee_email_retry', array( $this, 'handle_email_retry' ) );
		add_action( 'admin_post_leadbee_deactivate', array( $this, 'handle_plugin_deactivation' ) );
		add_action( 'admin_post_leadbee_reset_appearance', array( $this, 'handle_reset_appearance' ) );
	}

	public function admin_menu() {
		add_menu_page( 'LeadBee', 'LeadBee', 'manage_options', 'leadbee-dashboard', array( $this, 'render_dashboard' ), 'dashicons-format-chat', 58 );
		add_submenu_page( 'leadbee-dashboard', 'Dashboard', 'Dashboard', 'manage_options', 'leadbee-dashboard', array( $this, 'render_dashboard' ) );
		add_submenu_page( 'leadbee-dashboard', 'Leads', 'Leads', 'manage_options', 'leadbee-leads', array( $this, 'render_leads' ) );
		add_submenu_page( 'leadbee-dashboard', 'Knowledge Base', 'Knowledge Base', 'manage_options', 'leadbee-knowledge-base', array( $this, 'render_knowledge_base' ) );
		add_submenu_page( 'leadbee-dashboard', 'Appearance', 'Appearance', 'manage_options', 'leadbee-appearance', array( $this, 'render_appearance' ) );
		add_submenu_page( 'leadbee-dashboard', 'Contact Settings', 'Contact Settings', 'manage_options', 'leadbee-contact-settings', array( $this, 'render_contacts' ) );
		add_submenu_page( 'leadbee-dashboard', 'Email Settings', 'Email Settings', 'manage_options', 'leadbee-email-settings', array( $this, 'render_email' ) );
		add_submenu_page( 'leadbee-dashboard', 'General Settings', 'General Settings', 'manage_options', 'leadbee-general-settings', array( $this, 'render_general' ) );
		add_submenu_page( 'leadbee-dashboard', 'Help & Documentation', 'Help & Documentation', 'manage_options', 'leadbee-help', array( $this, 'render_help' ) );
	}

	public function enqueue_assets( $hook ) {
		if ( 'plugins.php' === $hook && current_user_can( 'activate_plugins' ) ) {
			wp_enqueue_style( 'leadbee-deactivation', LEADBEE_URL . 'admin/assets/css/deactivation.css', array(), filemtime( LEADBEE_PATH . 'admin/assets/css/deactivation.css' ) );
			wp_enqueue_script( 'leadbee-deactivation', LEADBEE_URL . 'admin/assets/js/deactivation.js', array(), filemtime( LEADBEE_PATH . 'admin/assets/js/deactivation.js' ), true );
			wp_localize_script(
				'leadbee-deactivation',
				'LeadBeeDeactivation',
				array(
					'pluginFile' => plugin_basename( LEADBEE_FILE ),
					'postUrl'    => is_network_admin() ? network_admin_url( 'admin-post.php' ) : admin_url( 'admin-post.php' ),
					'nonce'      => wp_create_nonce( 'leadbee_deactivate' ),
					'strings'    => array(
						'title'        => __( 'Deactivate LeadBee', 'leadbee' ),
						'description'  => __( 'Choose what to do with LeadBee data before deactivating the plugin.', 'leadbee' ),
						'warning'      => __( 'Deleting data permanently removes saved leads, transcripts, notes, settings and the knowledge base. This cannot be undone.', 'leadbee' ),
						'confirmDelete'=> __( 'I understand and want to permanently delete all LeadBee data.', 'leadbee' ),
						'cancel'       => __( 'Cancel', 'leadbee' ),
						'keep'         => __( 'Keep data and deactivate', 'leadbee' ),
						'delete'       => __( 'Delete data and deactivate', 'leadbee' ),
					)
				)
			);
			return;
		}
		if ( false === strpos( $hook, 'leadbee' ) ) {
			return;
		}
		wp_enqueue_style( 'leadbee-admin', LEADBEE_URL . 'admin/assets/css/admin.css', array(), filemtime( LEADBEE_PATH . 'admin/assets/css/admin.css' ) );
		wp_enqueue_style( 'leadbee-admin-extra', LEADBEE_URL . 'admin/assets/css/admin-extra.css', array( 'leadbee-admin' ), filemtime( LEADBEE_PATH . 'admin/assets/css/admin-extra.css' ) );
		wp_enqueue_script( 'leadbee-admin', LEADBEE_URL . 'admin/assets/js/admin.js', array( 'jquery' ), filemtime( LEADBEE_PATH . 'admin/assets/js/admin.js' ), true );
		wp_enqueue_media();
	}

	public function register_settings() {
		register_setting( 'leadbee_appearance_group', 'leadbee_appearance', array( 'sanitize_callback' => array( $this, 'sanitize_appearance' ) ) );
		register_setting( 'leadbee_contacts_group', 'leadbee_contacts', array( 'sanitize_callback' => array( $this, 'sanitize_contacts' ) ) );
		register_setting( 'leadbee_general_group', 'leadbee_general', array( 'sanitize_callback' => array( $this, 'sanitize_general' ) ) );
		register_setting( 'leadbee_email_group', 'leadbee_email', array( 'sanitize_callback' => array( $this, 'sanitize_email' ) ) );
	}

	public function sanitize_appearance( $input ) { return $this->sanitize_section( 'appearance', $input ); }
	public function sanitize_contacts( $input ) { return $this->sanitize_section( 'contacts', $input ); }
	public function sanitize_general( $input ) { return $this->sanitize_section( 'general', $input ); }
	public function sanitize_email( $input ) { return $this->sanitize_section( 'email', $input ); }

	private function sanitize_section( $section, $input ) {
		$defaults = self::defaults()[ $section ];
		$old      = self::settings( $section );
		$input    = is_array( $input ) ? wp_unslash( $input ) : array();
		$checkboxes = array(
			'appearance' => array( 'animations', 'typing_indicator', 'button_hover', 'launcher_pulse', 'window_animation', 'powered_by_enabled' ),
			'contacts' => array( 'whatsapp_enabled', 'email_enabled', 'call_enabled', 'website_enabled', 'more_enabled' ),
			'general' => array( 'enabled', 'show_desktop', 'show_tablet', 'show_mobile', 'launcher_text_enabled', 'lead_collection', 'notifications_enabled', 'session_persistence', 'suggestions', 'small_talk', 'debug_mode', 'delete_data_on_uninstall' ),
			'email' => array( 'smtp_auth' ),
		);
		$out = $old;
		foreach ( $defaults as $key => $default ) {
			if ( in_array( $key, $checkboxes[ $section ], true ) ) {
				$out[ $key ] = isset( $input[ $key ] ) ? 1 : 0;
				continue;
			}
			if ( ! array_key_exists( $key, $input ) ) {
				continue;
			}
			$value = is_scalar( $input[ $key ] ) ? trim( (string) $input[ $key ] ) : '';
			if ( 'email' === $section && 'smtp_password' === $key ) {
				if ( '' !== $value ) {
					$encrypted = LeadBee_Security::encrypt_secret( $value );
					if ( is_wp_error( $encrypted ) ) {
						add_settings_error( 'leadbee_email', 'smtp_password', $encrypted->get_error_message(), 'error' );
					} else {
						$out[ $key ] = $encrypted;
					}
				}
				continue;
			}
			if ( in_array( $key, array( 'primary_color','secondary_color','accent_color','header_background','welcome_background','conversation_background','user_bubble','bot_bubble','user_text','bot_text','button_background','button_text','secondary_button_background','secondary_button_text','input_background','input_border','footer_background','status_color','link_color','hover_color','text_color','muted_color','border_color','soft_color' ), true ) ) {
				$out[ $key ] = sanitize_hex_color( $value ) ? sanitize_hex_color( $value ) : $default;
			} elseif ( false !== strpos( $key, 'email' ) || 'recipient' === $key || 'reply_to' === $key ) {
				$out[ $key ] = sanitize_email( $value );
			} elseif ( in_array( $key, array( 'website','privacy_url','avatar_url' ), true ) ) {
				$out[ $key ] = esc_url_raw( $value );
			} elseif ( is_int( $default ) || is_numeric( $default ) ) {
				$out[ $key ] = $this->bounded_number( $key, $value, $default );
			} elseif ( in_array( $key, array( 'display_rule','method','smtp_encryption','font_family','fallback_behaviour','launcher_icon','avatar_icon','desktop_position','mobile_position' ), true ) ) {
				$out[ $key ] = sanitize_key( $value );
			} elseif ( 'page_ids' === $key ) {
				$out[ $key ] = implode( ',', array_slice( array_unique( array_filter( array_map( 'absint', explode( ',', $value ) ) ) ), 0, 100 ) );
			} elseif ( in_array( $key, array( 'welcome_heading','welcome_description','cc','greeting' ), true ) ) {
				$out[ $key ] = sanitize_textarea_field( $value );
			} else {
				$out[ $key ] = sanitize_text_field( $value );
			}
		}
		if ( 'appearance' === $section ) {
			$out['panel_width'] = min( 600, max( 320, absint( $out['panel_width'] ) ) );
			$out['panel_height'] = min( 900, max( 420, absint( $out['panel_height'] ) ) );
			$out['typing_min'] = min( 5000, absint( $out['typing_min'] ) );
			$out['typing_max'] = max( $out['typing_min'], min( 7000, absint( $out['typing_max'] ) ) );
			if ( ! in_array( $out['font_family'], array( 'Plus Jakarta Sans', 'Arial', 'system-ui' ), true ) ) { $out['font_family'] = 'Plus Jakarta Sans'; }
			if ( ! in_array( $out['desktop_position'], array( 'left', 'right' ), true ) ) { $out['desktop_position'] = 'right'; }
			if ( ! in_array( $out['mobile_position'], array( 'bottom', 'right' ), true ) ) { $out['mobile_position'] = 'bottom'; }
			$icon_choices = array(
				'avatar_icon' => array( 'chat', 'spark' ), 'send_icon' => array( 'arrow', 'chat', 'spark', 'mail' ),
				'back_icon' => array( 'back', 'arrow' ), 'close_icon' => array( 'close', 'chat', 'spark' ),
				'restart_icon' => array( 'restart', 'arrow', 'chat' ), 'whatsapp_icon' => array( 'whatsapp', 'phone', 'chat' ),
				'email_icon' => array( 'mail', 'chat', 'spark' ), 'phone_icon' => array( 'phone', 'chat' ),
				'website_icon' => array( 'web', 'chat', 'spark' ), 'privacy_icon' => array( 'shield', 'chat' ),
			);
			foreach ( $icon_choices as $icon_key => $choices ) {
				if ( ! in_array( $out[ $icon_key ], $choices, true ) ) { $out[ $icon_key ] = $defaults[ $icon_key ]; }
			}
		}
		if ( 'general' === $section ) {
			if ( ! in_array( $out['display_rule'], array( 'all', 'selected', 'hidden', 'home' ), true ) ) { $out['display_rule'] = 'all'; }
			if ( ! in_array( $out['launcher_icon'], array( 'chat', 'spark' ), true ) ) { $out['launcher_icon'] = 'chat'; }
			if ( ! in_array( $out['fallback_behaviour'], array( 'friendly', 'driving' ), true ) ) { $out['fallback_behaviour'] = 'friendly'; }
			$out['max_suggestions'] = min( 6, max( 0, absint( $out['max_suggestions'] ) ) );
			$out['match_sensitivity'] = min( 100, max( 50, absint( $out['match_sensitivity'] ) ) );
		}
		if ( 'email' === $section ) {
			if ( ! in_array( $out['method'], array( 'wordpress', 'custom' ), true ) ) { $out['method'] = 'wordpress'; }
			if ( ! in_array( $out['smtp_encryption'], array( 'none', 'ssl', 'tls' ), true ) ) { $out['smtp_encryption'] = 'tls'; }
			$out['smtp_port'] = min( 65535, max( 1, absint( $out['smtp_port'] ) ) );
		}
		return $out;
	}

	private function bounded_number( $key, $value, $default ) {
		$number = is_numeric( $value ) ? (float) $value : (float) $default;
		$limits = array(
			'base_font_size' => array( 10, 20 ), 'heading_font_size' => array( 18, 42 ), 'font_weight' => array( 400, 900 ),
			'button_font_weight' => array( 400, 900 ), 'line_height' => array( 1.2, 2.4 ), 'bottom_offset' => array( 0, 200 ),
			'right_offset' => array( 0, 200 ), 'border_radius' => array( 0, 40 ), 'shadow_intensity' => array( 0, 80 ),
			'launcher_size' => array( 52, 96 ), 'typing_min' => array( 0, 5000 ), 'typing_max' => array( 0, 7000 ),
			'max_suggestions' => array( 0, 6 ), 'match_sensitivity' => array( 50, 100 ), 'smtp_port' => array( 1, 65535 ), 'retention_days' => array( 0, 3650 ),
		);
		$range = isset( $limits[ $key ] ) ? $limits[ $key ] : array( 0, 10000 );
		$number = max( $range[0], min( $range[1], $number ) );
		return is_float( $default ) ? (string) $number : (int) $number;
	}

	public function render_dashboard() {
		$this->require_access();
		global $wpdb;
		$table = LeadBee_Database::table();
		$timezone = wp_timezone();
		$today_start = ( new DateTimeImmutable( 'today', $timezone ) )->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		$tomorrow_start = ( new DateTimeImmutable( 'tomorrow', $timezone ) )->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		$month_start = ( new DateTimeImmutable( 'first day of this month 00:00:00', $timezone ) )->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		$stats = array(
			'total' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ),
			'new' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", 'new' ) ),
			'contacted' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", 'contacted' ) ),
			'converted' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", 'converted' ) ),
			'today' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s AND created_at < %s", $today_start, $tomorrow_start ) ),
			'month' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", $month_start ) ),
			'email_failures' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE email_status = %s", 'failed' ) ),
		);
		$recent = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT 8" );
		$email_failures = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE email_status = %s ORDER BY created_at DESC LIMIT 5", 'failed' ) );
		$general = self::settings( 'general' );
		$kb = LeadBee_Knowledge_Base::active();
		$kb_status = LeadBee_Knowledge_Base::validate( $kb );
		$this->page_header( 'Dashboard' );
		include LEADBEE_PATH . 'admin/views/dashboard.php';
		$this->page_footer();
	}

	public function render_leads() {
		$this->require_access();
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		if ( $id && isset( $_GET['view'] ) && 'detail' === sanitize_key( wp_unslash( $_GET['view'] ) ) ) {
			$lead = LeadBee_Database::get( $id );
			if ( ! $lead ) { wp_die( esc_html__( 'Lead not found.', 'leadbee' ) ); }
			$this->page_header( 'Lead details' );
			include LEADBEE_PATH . 'admin/views/lead-detail.php';
			$this->page_footer();
			return;
		}
		global $wpdb;
		$table  = LeadBee_Database::table();
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$type   = isset( $_GET['lesson_type'] ) ? sanitize_key( wp_unslash( $_GET['lesson_type'] ) ) : '';
		$from   = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to     = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$sort   = isset( $_GET['sort'] ) && 'oldest' === $_GET['sort'] ? 'ASC' : 'DESC';
		$paged  = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );
		$limit  = 25;
		$where  = array( '1=1' );
		$args   = array();
		if ( in_array( $status, LeadBee_Database::statuses(), true ) ) { $where[] = 'status = %s'; $args[] = $status; }
		if ( in_array( ucfirst( $type ), array( 'Manual', 'Automatic' ), true ) ) { $where[] = 'lesson_type = %s'; $args[] = ucfirst( $type ); }
		if ( $from && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) && checkdate( (int) substr( $from, 5, 2 ), (int) substr( $from, 8, 2 ), (int) substr( $from, 0, 4 ) ) ) { $where[] = 'created_at >= %s'; $args[] = get_gmt_from_date( $from . ' 00:00:00' ); }
		if ( $to && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) && checkdate( (int) substr( $to, 5, 2 ), (int) substr( $to, 8, 2 ), (int) substr( $to, 0, 4 ) ) ) { $where[] = 'created_at <= %s'; $args[] = get_gmt_from_date( $to . ' 23:59:59' ); }
		if ( $search ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$where[] = '(full_name LIKE %s OR phone LIKE %s OR email LIKE %s OR address LIKE %s OR lead_uuid LIKE %s)';
			array_push( $args, $like, $like, $like, $like, $like );
		}
		$sql = "SELECT SQL_CALC_FOUND_ROWS * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY created_at {$sort} LIMIT %d OFFSET %d";
		array_push( $args, $limit, ( $paged - 1 ) * $limit );
		$rows  = $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
		$total = (int) $wpdb->get_var( 'SELECT FOUND_ROWS()' );
		$this->page_header( 'Leads' );
		include LEADBEE_PATH . 'admin/views/leads.php';
		$this->page_footer();
	}

	public function handle_lead_update() {
		$this->verify_action( 'leadbee_lead_update' );
		$id     = isset( $_POST['lead_id'] ) ? absint( $_POST['lead_id'] ) : 0;
		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'new';
		$notes  = isset( $_POST['admin_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['admin_notes'] ) ) : '';
		if ( ! in_array( $status, LeadBee_Database::statuses(), true ) ) { $status = 'new'; }
		global $wpdb;
		$wpdb->update( LeadBee_Database::table(), array( 'status' => $status, 'admin_notes' => $notes ), array( 'id' => $id ), array( '%s', '%s' ), array( '%d' ) );
		wp_safe_redirect( add_query_arg( array( 'page' => 'leadbee-leads', 'view' => 'detail', 'id' => $id, 'updated' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_lead_delete() {
		$this->verify_action( 'leadbee_lead_delete' );
		$ids = isset( $_POST['lead_ids'] ) ? array_map( 'absint', (array) $_POST['lead_ids'] ) : array();
		$id  = isset( $_POST['lead_id'] ) ? absint( $_POST['lead_id'] ) : 0;
		if ( $id ) { $ids[] = $id; }
		$ids = array_values( array_filter( array_unique( $ids ) ) );
		if ( $ids ) {
			global $wpdb;
			$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
			$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . LeadBee_Database::table() . " WHERE id IN ({$placeholders})", $ids ) );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=leadbee-leads&deleted=1' ) );
		exit;
	}

	public function handle_export() {
		$this->verify_action( 'leadbee_export' );
		global $wpdb;
		$where = array( '1=1' );
		$args  = array();
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$type = isset( $_GET['lesson_type'] ) ? sanitize_key( wp_unslash( $_GET['lesson_type'] ) ) : '';
		$from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		if ( in_array( $status, LeadBee_Database::statuses(), true ) ) { $where[] = 'status = %s'; $args[] = $status; }
		if ( in_array( ucfirst( $type ), array( 'Manual', 'Automatic' ), true ) ) { $where[] = 'lesson_type = %s'; $args[] = ucfirst( $type ); }
		if ( $from && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) && checkdate( (int) substr( $from, 5, 2 ), (int) substr( $from, 8, 2 ), (int) substr( $from, 0, 4 ) ) ) { $where[] = 'created_at >= %s'; $args[] = get_gmt_from_date( $from . ' 00:00:00' ); }
		if ( $to && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) && checkdate( (int) substr( $to, 5, 2 ), (int) substr( $to, 8, 2 ), (int) substr( $to, 0, 4 ) ) ) { $where[] = 'created_at <= %s'; $args[] = get_gmt_from_date( $to . ' 23:59:59' ); }
		if ( $search ) { $like = '%' . $wpdb->esc_like( $search ) . '%'; $where[] = '(full_name LIKE %s OR phone LIKE %s OR email LIKE %s OR address LIKE %s OR lead_uuid LIKE %s)'; array_push( $args, $like, $like, $like, $like, $like ); }
		$sql = 'SELECT * FROM ' . LeadBee_Database::table() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY created_at DESC';
		$rows = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=leadbee-leads-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'Lead ID', 'Name', 'Email', 'Phone', 'Address', 'Lesson Type', 'Availability', 'Additional Requirements', 'Submitted UTC', 'Status', 'Email Status', 'Email Error', 'Internal Notes', 'Transcript' ) );
		foreach ( $rows as $row ) {
			fputcsv( $out, array_map( array( $this, 'csv_safe' ), array( $row['lead_uuid'], $row['full_name'], $row['email'], $row['phone'], $row['address'], $row['lesson_type'], $row['availability'], $row['additional_requirements'], $row['created_at'], $row['status'], $row['email_status'], $row['email_error'], $row['admin_notes'], $row['transcript'] ) ) );
		}
		fclose( $out );
		exit;
	}

	public function csv_safe( $value ) {
		$value = (string) $value;
		return preg_match( '/^[\s\x00-\x20]*[=+@\-]/', $value ) ? "'" . $value : $value;
	}

	private function require_access() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'You do not have permission to access LeadBee.', 'leadbee' ) ); }
	}

	private function verify_action( $nonce_action ) {
		$this->require_access();
		check_admin_referer( $nonce_action );
	}

	private function page_header( $title ) {
		include LEADBEE_PATH . 'admin/views/header.php';
	}

	private function page_footer() {
		echo '</div>';
	}

	public function render_knowledge_base() {
		$this->require_access();
		$active = LeadBee_Knowledge_Base::active();
		$check  = LeadBee_Knowledge_Base::validate( $active );
		$backups = get_option( 'leadbee_knowledge_base_backups', array() );
		$preview = isset( $_GET['preview'] ) && '1' === $_GET['preview'] ? get_transient( 'leadbee_kb_preview_' . get_current_user_id() ) : false;
		$this->page_header( 'Knowledge Base' );
		include LEADBEE_PATH . 'admin/views/knowledge-base.php';
		$this->page_footer();
	}

	public function handle_kb_import() {
		$this->verify_action( 'leadbee_kb_import' );
		if ( empty( $_FILES['knowledge_base']['tmp_name'] ) || ! is_uploaded_file( $_FILES['knowledge_base']['tmp_name'] ) ) {
			$this->redirect_notice( 'leadbee-knowledge-base', 'kb_invalid_upload' );
		}
		$file = $_FILES['knowledge_base'];
		if ( ! empty( $file['size'] ) && $file['size'] > 2097152 ) {
			$this->redirect_notice( 'leadbee-knowledge-base', 'kb_too_large' );
		}
		$filename = sanitize_file_name( $file['name'] );
		if ( 'json' !== strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) ) {
			$this->redirect_notice( 'leadbee-knowledge-base', 'kb_invalid_type' );
		}
		$raw  = file_get_contents( $file['tmp_name'] );
		$data = json_decode( $raw, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
			set_transient( 'leadbee_kb_errors_' . get_current_user_id(), array( sprintf( __( 'JSON syntax error: %s', 'leadbee' ), json_last_error_msg() ) ), MINUTE_IN_SECONDS * 5 );
			$this->redirect_notice( 'leadbee-knowledge-base', 'kb_validation_failed' );
		}
		$validation = LeadBee_Knowledge_Base::validate( $data );
		if ( ! $validation['valid'] ) {
			set_transient( 'leadbee_kb_errors_' . get_current_user_id(), $validation['errors'], MINUTE_IN_SECONDS * 5 );
			$this->redirect_notice( 'leadbee-knowledge-base', 'kb_validation_failed' );
		}
		set_transient( 'leadbee_kb_preview_' . get_current_user_id(), $data, HOUR_IN_SECONDS );
		wp_safe_redirect( admin_url( 'admin.php?page=leadbee-knowledge-base&preview=1' ) );
		exit;
	}

	public function handle_kb_confirm() {
		$this->verify_action( 'leadbee_kb_confirm' );
		$key       = 'leadbee_kb_preview_' . get_current_user_id();
		$candidate = get_transient( $key );
		if ( ! is_array( $candidate ) || ! LeadBee_Knowledge_Base::validate( $candidate )['valid'] ) {
			$this->redirect_notice( 'leadbee-knowledge-base', 'kb_preview_expired' );
		}
		$backups = get_option( 'leadbee_knowledge_base_backups', array() );
		array_unshift( $backups, array( 'saved_at' => current_time( 'mysql' ), 'data' => LeadBee_Knowledge_Base::active() ) );
		update_option( 'leadbee_knowledge_base_backups', array_slice( $backups, 0, 3 ), false );
		update_option( 'leadbee_knowledge_base', $candidate, false );
		update_option( 'leadbee_knowledge_base_updated', current_time( 'mysql' ), false );
		delete_transient( $key );
		$this->redirect_notice( 'leadbee-knowledge-base', 'kb_replaced' );
	}

	public function handle_kb_cancel() {
		$this->verify_action( 'leadbee_kb_cancel' );
		delete_transient( 'leadbee_kb_preview_' . get_current_user_id() );
		$this->redirect_notice( 'leadbee-knowledge-base', 'kb_cancelled' );
	}

	public function handle_kb_restore() {
		$this->verify_action( 'leadbee_kb_restore' );
		$default = LeadBee_Knowledge_Base::read_default();
		if ( ! is_array( $default ) || ! LeadBee_Knowledge_Base::validate( $default )['valid'] ) {
			$this->redirect_notice( 'leadbee-knowledge-base', 'kb_default_invalid' );
		}
		$backups = get_option( 'leadbee_knowledge_base_backups', array() );
		array_unshift( $backups, array( 'saved_at' => current_time( 'mysql' ), 'data' => LeadBee_Knowledge_Base::active() ) );
		update_option( 'leadbee_knowledge_base_backups', array_slice( $backups, 0, 3 ), false );
		update_option( 'leadbee_knowledge_base', $default, false );
		update_option( 'leadbee_knowledge_base_updated', current_time( 'mysql' ), false );
		$this->redirect_notice( 'leadbee-knowledge-base', 'kb_restored' );
	}

	public function handle_kb_rollback() {
		$this->verify_action( 'leadbee_kb_rollback' );
		$backups = get_option( 'leadbee_knowledge_base_backups', array() );
		if ( empty( $backups[0]['data'] ) || ! is_array( $backups[0]['data'] ) || ! LeadBee_Knowledge_Base::validate( $backups[0]['data'] )['valid'] ) {
			$this->redirect_notice( 'leadbee-knowledge-base', 'kb_rollback_unavailable' );
		}
		$previous = $backups[0]['data'];
		array_unshift( $backups, array( 'saved_at' => current_time( 'mysql' ), 'data' => LeadBee_Knowledge_Base::active() ) );
		update_option( 'leadbee_knowledge_base_backups', array_slice( $backups, 0, 3 ), false );
		update_option( 'leadbee_knowledge_base', $previous, false );
		update_option( 'leadbee_knowledge_base_updated', current_time( 'mysql' ), false );
		$this->redirect_notice( 'leadbee-knowledge-base', 'kb_rolled_back' );
	}

	public function handle_kb_export() {
		$this->verify_action( 'leadbee_kb_export' );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=leadbee-knowledge-base.json' );
		echo wp_json_encode( LeadBee_Knowledge_Base::active(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		exit;
	}

	public function render_appearance() { $this->render_settings( 'appearance', 'Appearance' ); }
	public function render_contacts() { $this->render_settings( 'contacts', 'Contact Settings' ); }
	public function render_email() { $this->render_settings( 'email', 'Email Settings' ); }
	public function render_general() { $this->render_settings( 'general', 'General Settings' ); }

	public function handle_email_test() {
		$this->verify_action( 'leadbee_email_test' );
		$result = LeadBee_Mailer::test_email();
		$this->redirect_notice( 'leadbee-email-settings', is_wp_error( $result ) ? 'email_test_failed' : 'email_test_sent' );
	}

	public function handle_email_retry() {
		$this->verify_action( 'leadbee_email_retry' );
		$id   = isset( $_POST['lead_id'] ) ? absint( $_POST['lead_id'] ) : 0;
		$lead = LeadBee_Database::get( $id );
		if ( ! $lead ) {
			wp_die( esc_html__( 'Lead not found.', 'leadbee' ) );
		}
		$general = self::settings( 'general' );
		if ( empty( $general['notifications_enabled'] ) ) {
			$notice = 'email_retry_disabled';
		} else {
			$notice = LeadBee_Mailer::notify( $id ) ? 'email_retry_sent' : 'email_retry_failed';
		}
		wp_safe_redirect( add_query_arg( array( 'page' => 'leadbee-leads', 'view' => 'detail', 'id' => $id, 'leadbee_notice' => $notice ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_plugin_deactivation() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			wp_die( esc_html__( 'You do not have permission to deactivate plugins.', 'leadbee' ) );
		}
		check_admin_referer( 'leadbee_deactivate' );
		$plugin = isset( $_POST['plugin'] ) ? sanitize_text_field( wp_unslash( $_POST['plugin'] ) ) : '';
		$choice = isset( $_POST['data_choice'] ) ? sanitize_key( wp_unslash( $_POST['data_choice'] ) ) : '';
		if ( plugin_basename( LEADBEE_FILE ) !== $plugin || ! in_array( $choice, array( 'keep', 'delete' ), true ) ) {
			wp_die( esc_html__( 'The deactivation request could not be verified.', 'leadbee' ) );
		}
		if ( 'delete' === $choice && ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to delete LeadBee data.', 'leadbee' ) );
		}
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$network_wide = isset( $_POST['networkwide'] ) && '1' === $_POST['networkwide'];
		if ( is_multisite() && function_exists( 'is_plugin_active_for_network' ) && is_plugin_active_for_network( $plugin ) ) {
			$network_wide = true;
		}
		deactivate_plugins( $plugin, false, $network_wide );
		if ( 'delete' === $choice ) {
			if ( $network_wide && is_multisite() ) {
				$site_ids = get_sites( array( 'fields' => 'ids', 'number' => 0 ) );
				foreach ( $site_ids as $site_id ) {
					switch_to_blog( $site_id );
					LeadBee_Database::delete_all_data();
					restore_current_blog();
				}
			} else {
				LeadBee_Database::delete_all_data();
			}
		}
		$redirect = $network_wide ? network_admin_url( 'plugins.php' ) : admin_url( 'plugins.php' );
		wp_safe_redirect( add_query_arg( array( 'deactivate' => 'true', 'leadbee_data' => 'delete' === $choice ? 'deleted' : 'kept' ), $redirect ) );
		exit;
	}

	public function handle_reset_appearance() {
		$this->verify_action( 'leadbee_reset_appearance' );
		update_option( 'leadbee_appearance', self::defaults()['appearance'], false );
		$this->redirect_notice( 'leadbee-appearance', 'appearance_reset' );
	}

	public function render_help() {
		$this->require_access();
		$this->page_header( 'Help & Documentation' );
		include LEADBEE_PATH . 'admin/views/help.php';
		$this->page_footer();
	}

	private function render_settings( $section, $title ) {
		$this->require_access();
		$values = self::settings( $section );
		$last_email_status = 'email' === $section ? get_option( 'leadbee_last_email_status', array() ) : array();
		$fields = $this->get_fields( $section );
		$this->page_header( $title );
		include LEADBEE_PATH . 'admin/views/settings.php';
		$this->page_footer();
	}

	private function get_fields( $section ) {
		$fields = array();
		$add = function( $key, $label, $type = 'text', $help = '', $extra = array() ) use ( &$fields ) {
			$fields[ $key ] = array_merge( array( 'label' => $label, 'type' => $type, 'help' => $help ), $extra );
		};
		if ( 'appearance' === $section ) {
			$add( 'display_name', 'Chatbot display name', 'text', 'Used in the chat label and contact links.' );
			$add( 'assistant_name', 'Assistant name', 'text' );
			$add( 'welcome_heading', 'Welcome heading', 'textarea', 'Line breaks are preserved in the welcome screen.' );
			$add( 'welcome_icon', 'Welcome icon (emoji)', 'text', 'Defaults to the waving hand used in the existing chatbot.' );
			$add( 'welcome_description', 'Welcome description', 'textarea' );
			$add( 'header_subtitle', 'Header subtitle', 'text' );
			$add( 'status_text', 'Status text', 'text' );
			$add( 'avatar_url', 'Header avatar or logo', 'media', 'Choose an image from the WordPress media library. SVG uploads are not enabled.' );
			$add( 'footer_text', 'Footer text', 'text' );
			$add( 'powered_by_enabled', 'Show Powered by text', 'checkbox' );
			foreach ( array( 'primary_color'=>'Primary colour','secondary_color'=>'Secondary colour','accent_color'=>'Accent colour','header_background'=>'Header background','welcome_background'=>'Welcome screen background','conversation_background'=>'Conversation background','user_bubble'=>'User message bubble','bot_bubble'=>'Assistant message bubble','user_text'=>'User message text','bot_text'=>'Assistant message text','button_background'=>'Primary button background','button_text'=>'Primary button text','secondary_button_background'=>'Secondary button background','secondary_button_text'=>'Secondary button text','input_background'=>'Input background','input_border'=>'Input border','footer_background'=>'Footer background','status_color'=>'Status indicator','link_color'=>'Link colour','hover_color'=>'Hover colour','text_color'=>'Main text colour','muted_color'=>'Muted text colour','border_color'=>'Border colour','soft_color'=>'Soft background' ) as $key => $label ) { $add( $key, $label, 'color' ); }
			$add( 'font_family', 'Font family', 'select', '', array( 'choices' => array( 'Plus Jakarta Sans'=>'Plus Jakarta Sans', 'Arial'=>'Arial', 'system-ui'=>'System UI' ) ) );
			$add( 'base_font_size', 'Base font size', 'number', '', array( 'min'=>10, 'max'=>20 ) );
			$add( 'heading_font_size', 'Heading font size', 'number', '', array( 'min'=>18, 'max'=>42 ) );
			$add( 'font_weight', 'Font weight', 'number', '', array( 'min'=>400, 'max'=>900, 'step'=>100 ) );
			$add( 'button_font_weight', 'Button font weight', 'number', '', array( 'min'=>400, 'max'=>900, 'step'=>100 ) );
			$add( 'line_height', 'Line height', 'number', '', array( 'min'=>1.2, 'max'=>2.4, 'step'=>0.1 ) );
			$add( 'panel_width', 'Chat window width (px)', 'number', '', array( 'min'=>320, 'max'=>600 ) );
			$add( 'panel_height', 'Chat window height (px)', 'number', '', array( 'min'=>420, 'max'=>900 ) );
			$add( 'desktop_position', 'Desktop position', 'select', '', array( 'choices'=>array( 'right'=>'Bottom right', 'left'=>'Bottom left' ) ) );
			$add( 'mobile_position', 'Mobile position', 'select', '', array( 'choices'=>array( 'bottom'=>'Full screen', 'right'=>'Bottom right' ) ) );
			$add( 'bottom_offset', 'Bottom offset (px)', 'number', '', array( 'min'=>0, 'max'=>200 ) );
			$add( 'right_offset', 'Right offset (px)', 'number', '', array( 'min'=>0, 'max'=>200 ) );
			$add( 'border_radius', 'Border radius (px)', 'number', '', array( 'min'=>0, 'max'=>40 ) );
			$add( 'shadow_intensity', 'Shadow intensity', 'number', '', array( 'min'=>0, 'max'=>80 ) );
			$add( 'launcher_size', 'Launcher size (px)', 'number', '', array( 'min'=>52, 'max'=>96 ) );
			$add( 'animations', 'Enable animations', 'checkbox' );
			$add( 'typing_indicator', 'Enable typing indicator', 'checkbox' );
			$add( 'typing_min', 'Minimum typing delay (ms)', 'number', '', array( 'min'=>0, 'max'=>5000 ) );
			$add( 'typing_max', 'Maximum typing delay (ms)', 'number', '', array( 'min'=>0, 'max'=>7000 ) );
			$add( 'button_hover', 'Button hover effects', 'checkbox' );
			$add( 'launcher_pulse', 'Launcher pulse animation', 'checkbox' );
			$add( 'window_animation', 'Window open and close animation', 'checkbox' );
			$add( 'avatar_icon', 'Header icon', 'select', '', array( 'choices'=>array( 'chat'=>'Chat bubble', 'spark'=>'Sparkle' ) ) );
			$add( 'send_icon', 'Send button icon', 'select', '', array( 'choices'=>array( 'arrow'=>'Arrow', 'chat'=>'Chat bubble', 'spark'=>'Sparkle', 'mail'=>'Envelope' ) ) );
			$add( 'back_icon', 'Back button icon', 'select', '', array( 'choices'=>array( 'back'=>'Back arrow', 'arrow'=>'Right arrow' ) ) );
			$add( 'close_icon', 'Close button icon', 'select', '', array( 'choices'=>array( 'close'=>'Close', 'chat'=>'Chat bubble', 'spark'=>'Sparkle' ) ) );
			$add( 'restart_icon', 'Restart button icon', 'select', '', array( 'choices'=>array( 'restart'=>'Restart', 'arrow'=>'Arrow', 'chat'=>'Chat bubble' ) ) );
			$add( 'whatsapp_icon', 'WhatsApp icon', 'select', '', array( 'choices'=>array( 'whatsapp'=>'WhatsApp', 'phone'=>'Phone', 'chat'=>'Chat bubble' ) ) );
			$add( 'email_icon', 'Email icon', 'select', '', array( 'choices'=>array( 'mail'=>'Envelope', 'chat'=>'Chat bubble', 'spark'=>'Sparkle' ) ) );
			$add( 'phone_icon', 'Phone icon', 'select', '', array( 'choices'=>array( 'phone'=>'Phone', 'chat'=>'Chat bubble' ) ) );
			$add( 'website_icon', 'Website icon', 'select', '', array( 'choices'=>array( 'web'=>'Globe', 'chat'=>'Chat bubble', 'spark'=>'Sparkle' ) ) );
			$add( 'privacy_icon', 'Privacy icon', 'select', '', array( 'choices'=>array( 'shield'=>'Shield', 'chat'=>'Chat bubble' ) ) );
		} elseif ( 'contacts' === $section ) {
			$add( 'business_name', 'Business name', 'text' );
			$add( 'email', 'Contact email', 'email' );
			$add( 'phone', 'Primary phone number', 'text' );
			$add( 'whatsapp', 'WhatsApp number', 'text', 'Use the full international number without spaces. The country code is not inferred.' );
			$add( 'website', 'Website URL', 'url' );
			$add( 'additional_phone', 'Additional phone number', 'text' );
			$add( 'additional_email', 'Additional contact email', 'email' );
			$add( 'additional_phone_label', 'Additional phone label', 'text' );
			$add( 'additional_email_label', 'Additional email label', 'text' );
			$add( 'privacy_url', 'Privacy information URL', 'url' );
			$add( 'whatsapp_enabled', 'Show WhatsApp card', 'checkbox' );
			$add( 'email_enabled', 'Show email card', 'checkbox' );
			$add( 'call_enabled', 'Enable call option', 'checkbox' );
			$add( 'website_enabled', 'Show website link', 'checkbox' );
			$add( 'more_enabled', 'Show more contact options', 'checkbox' );
			$add( 'call_label', 'Call option label', 'text' );
			$add( 'website_label', 'Website link label', 'text' );
		} elseif ( 'general' === $section ) {
			$add( 'enabled', 'Enable chatbot', 'checkbox' );
			$add( 'display_rule', 'Page display rule', 'select', '', array( 'choices'=>array( 'all'=>'All pages', 'selected'=>'Selected pages only', 'hidden'=>'Hide on selected pages', 'home'=>'Homepage only' ) ) );
			$add( 'page_ids', 'Page or post IDs', 'text', 'Comma separated IDs for the selected-page rules.' );
			$add( 'show_desktop', 'Show on desktop', 'checkbox' );
			$add( 'show_tablet', 'Show on tablet', 'checkbox' );
			$add( 'show_mobile', 'Show on mobile', 'checkbox' );
			$add( 'launcher_text_enabled', 'Show launcher label', 'checkbox' );
			$add( 'launcher_text', 'Launcher label', 'text' );
			$add( 'launcher_icon', 'Launcher icon', 'select', '', array( 'choices'=>array( 'chat'=>'Chat bubble', 'spark'=>'Sparkle' ) ) );
			$add( 'lead_collection', 'Enable lead collection', 'checkbox' );
			$add( 'notifications_enabled', 'Enable email notifications', 'checkbox' );
			$add( 'session_persistence', 'Restore conversation in this tab', 'checkbox' );
			$add( 'suggestions', 'Show suggested questions', 'checkbox' );
			$add( 'max_suggestions', 'Maximum suggested questions', 'number', '', array( 'min'=>0, 'max'=>6 ) );
			$add( 'small_talk', 'Enable small talk', 'checkbox' );
			$add( 'match_sensitivity', 'Knowledge matching sensitivity (%)', 'number', 'Lower values allow more approximate matches; higher values require a closer match.', array( 'min'=>50, 'max'=>100 ) );
			$add( 'greeting', 'Opening greeting', 'textarea' );
			$add( 'fallback_behaviour', 'Fallback behaviour', 'select', '', array( 'choices'=>array( 'friendly'=>'Friendly clarification', 'driving'=>'Driving topics only' ) ) );
			$add( 'debug_mode', 'Debug mode (administrators only)', 'checkbox', 'Debug mode writes no visitor messages or personal information to public output.' );
			$add( 'retention_days', 'Automatic lead retention (days)', 'number', 'Set 0 to keep leads until an administrator deletes them. Automatic deletion only applies when you set a number above 0.', array( 'min'=>0, 'max'=>3650 ) );
			$add( 'delete_data_on_uninstall', 'Delete plugin data on uninstall', 'checkbox', 'Off by default. Leads and settings remain when the plugin is uninstalled unless you enable this.' );
		} else {
			$add( 'method', 'Email delivery method', 'select', 'WordPress email uses wp_mail() and respects an SMTP plugin already configured on this site.', array( 'choices'=>array( 'wordpress'=>'Existing WordPress email (recommended)', 'custom'=>'LeadBee custom SMTP' ) ) );
			$add( 'recipient', 'Admin recipient email', 'email' );
			$add( 'cc', 'CC emails', 'text', 'Optional comma-separated email addresses.' );
			$add( 'subject', 'Email subject template', 'text', 'Available placeholders: {{lead_id}} and {{name}}.' );
			$add( 'from_name', 'From name', 'text', 'Used with LeadBee custom SMTP. In WordPress email mode, WP Mail SMTP controls the sender.' );
			$add( 'from_email', 'From email', 'email', 'Used with LeadBee custom SMTP. In WordPress email mode, WP Mail SMTP controls the sender.' );
			$add( 'reply_to', 'Reply-to email', 'email' );
			$add( 'smtp_host', 'SMTP host', 'text' );
			$add( 'smtp_port', 'SMTP port', 'number', '', array( 'min'=>1, 'max'=>65535 ) );
			$add( 'smtp_encryption', 'Encryption', 'select', '', array( 'choices'=>array( 'none'=>'None', 'ssl'=>'SSL', 'tls'=>'TLS' ) ) );
			$add( 'smtp_auth', 'SMTP authentication enabled', 'checkbox' );
			$add( 'smtp_username', 'SMTP username', 'text' );
			$add( 'smtp_password', 'SMTP password / app password', 'password', 'Stored encrypted. Leave blank to keep the current password.' );
		}
		return $fields;
	}

	public function field_control( $section, $key, $field, $values ) {
		$value = isset( $values[ $key ] ) ? $values[ $key ] : '';
		$name  = 'leadbee_' . $section . '[' . $key . ']';
		$id    = 'leadbee_' . $section . '_' . $key;
		$type  = $field['type'];
		if ( 'checkbox' === $type ) {
			echo '<label class="leadbee-toggle"><input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, 1, false ) . '><span class="leadbee-toggle-ui"></span></label>';
		} elseif ( 'select' === $type ) {
			echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( $field['choices'] as $choice => $label ) { echo '<option value="' . esc_attr( $choice ) . '" ' . selected( $value, $choice, false ) . '>' . esc_html( $label ) . '</option>'; }
			echo '</select>';
		} elseif ( 'textarea' === $type ) {
			echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="4" class="large-text">' . esc_textarea( $value ) . '</textarea>';
		} elseif ( 'media' === $type ) {
			echo '<div class="leadbee-media-control"><input class="regular-text" type="url" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"><button type="button" class="button leadbee-media-select" data-target="' . esc_attr( $id ) . '">' . esc_html__( 'Choose image', 'leadbee' ) . '</button></div>';
			if ( $value ) { echo '<img class="leadbee-media-preview" src="' . esc_url( $value ) . '" alt="">'; }
		} else {
			$attr_type = 'password' === $type ? 'password' : ( 'color' === $type ? 'color' : ( 'number' === $type ? 'number' : ( 'email' === $type ? 'email' : ( 'url' === $type ? 'url' : 'text' ) ) ) );
			$extra = '';
			foreach ( array( 'min', 'max', 'step' ) as $attr ) { if ( isset( $field[ $attr ] ) ) { $extra .= ' ' . $attr . '="' . esc_attr( $field[ $attr ] ) . '"'; } }
			if ( 'password' === $type ) { $value = ''; echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="">'; }
			echo '<input type="' . esc_attr( $attr_type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . $extra . ' class="' . ( in_array( $type, array( 'color', 'number' ), true ) ? 'small-text' : 'regular-text' ) . '"' . ( 'password' === $type ? ' autocomplete="new-password"' : '' ) . '>';
			if ( 'password' === $type ) { $saved = ! empty( self::settings( 'email' )['smtp_password'] ); echo '<span class="description">' . ( $saved ? esc_html__( 'A password is saved.', 'leadbee' ) : esc_html__( 'No password saved.', 'leadbee' ) ) . '</span>'; }
		}
	}

	private function redirect_notice( $page, $notice ) {
		wp_safe_redirect( add_query_arg( array( 'page' => $page, 'leadbee_notice' => $notice ), admin_url( 'admin.php' ) ) );
		exit;
	}
}
