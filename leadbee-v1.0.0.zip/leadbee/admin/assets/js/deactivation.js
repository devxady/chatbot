(function () {
  'use strict';

  const config = window.LeadBeeDeactivation;
  if (!config || !config.pluginFile) return;
  const strings = config.strings || {};
  let dialog = null;

  function field(form, name, value) {
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = name;
    input.value = value;
    form.appendChild(input);
  }

  function submitChoice(choice, networkWide) {
    const form = document.createElement('form');
    form.method = 'post';
    form.action = config.postUrl;
    field(form, 'action', 'leadbee_deactivate');
    field(form, '_wpnonce', config.nonce);
    field(form, 'plugin', config.pluginFile);
    field(form, 'data_choice', choice);
    field(form, 'networkwide', networkWide ? '1' : '0');
    document.body.appendChild(form);
    form.submit();
  }

  function closeDialog() {
    if (!dialog) return;
    dialog.remove();
    dialog = null;
    document.removeEventListener('keydown', onKeydown);
  }

  function onKeydown(event) {
    if (event.key === 'Escape') closeDialog();
  }

  function openDialog(networkWide) {
    if (dialog) return;
    const overlay = document.createElement('div');
    overlay.className = 'leadbee-deactivation-overlay';
    const panel = document.createElement('section');
    panel.className = 'leadbee-deactivation-dialog';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-labelledby', 'leadbee-deactivation-title');

    const title = document.createElement('h2');
    title.id = 'leadbee-deactivation-title';
    title.textContent = strings.title || 'Deactivate LeadBee';
    const description = document.createElement('p');
    description.textContent = strings.description || 'Choose what to do with LeadBee data before deactivating the plugin.';

    const warning = document.createElement('p');
    warning.className = 'leadbee-deactivation-warning';
    warning.textContent = strings.warning || 'Deleting data permanently removes all saved leads, transcripts, notes, settings and the knowledge base. This cannot be undone.';

    const confirmLabel = document.createElement('label');
    confirmLabel.className = 'leadbee-deactivation-confirm';
    const confirm = document.createElement('input');
    confirm.type = 'checkbox';
    const confirmText = document.createElement('span');
    confirmText.textContent = strings.confirmDelete || 'I understand and want to permanently delete all LeadBee data.';
    confirmLabel.append(confirm, confirmText);

    const actions = document.createElement('div');
    actions.className = 'leadbee-deactivation-actions';
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'button';
    cancel.textContent = strings.cancel || 'Cancel';
    cancel.addEventListener('click', closeDialog);
    const keep = document.createElement('button');
    keep.type = 'button';
    keep.className = 'button button-primary';
    keep.textContent = strings.keep || 'Keep data and deactivate';
    keep.addEventListener('click', function () { submitChoice('keep', networkWide); });
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'button button-link-delete';
    remove.disabled = true;
    remove.textContent = strings.delete || 'Delete data and deactivate';
    remove.addEventListener('click', function () { if (confirm.checked) submitChoice('delete', networkWide); });
    confirm.addEventListener('change', function () { remove.disabled = !confirm.checked; });
    actions.append(cancel, keep, remove);

    panel.append(title, description, warning, confirmLabel, actions);
    overlay.appendChild(panel);
    overlay.addEventListener('click', function (event) { if (event.target === overlay) closeDialog(); });
    document.body.appendChild(overlay);
    dialog = overlay;
    document.addEventListener('keydown', onKeydown);
    keep.focus();
  }

  document.addEventListener('click', function (event) {
    const link = event.target.closest && event.target.closest('a');
    if (!link) return;
    let url;
    try { url = new URL(link.href, window.location.href); } catch (error) { return; }
    if (url.searchParams.get('action') !== 'deactivate' || url.searchParams.get('plugin') !== config.pluginFile) return;
    event.preventDefault();
    openDialog(url.searchParams.get('networkwide') === '1');
  });
})();
