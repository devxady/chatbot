<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$notice = isset( $_GET['leadbee_notice'] ) ? sanitize_key( wp_unslash( $_GET['leadbee_notice'] ) ) : '';
$messages = array(
	'kb_invalid_upload' => __( 'Choose a JSON knowledge base file to upload.', 'leadbee' ),
	'kb_too_large' => __( 'The knowledge base file is larger than 2 MB.', 'leadbee' ),
	'kb_invalid_type' => __( 'Only .json files can be imported.', 'leadbee' ),
	'kb_validation_failed' => __( 'The knowledge base did not pass validation. Review the errors below.', 'leadbee' ),
	'kb_preview_expired' => __( 'The import preview expired. Upload the file again.', 'leadbee' ),
	'kb_replaced' => __( 'The active knowledge base has been replaced. A backup of the previous version was kept.', 'leadbee' ),
	'kb_cancelled' => __( 'The knowledge base import was cancelled.', 'leadbee' ),
	'kb_default_invalid' => __( 'The bundled default knowledge base failed validation.', 'leadbee' ),
	'kb_restored' => __( 'The bundled default knowledge base has been restored. A backup was kept.', 'leadbee' ),
	'kb_rolled_back' => __( 'The most recent knowledge base backup is active again.', 'leadbee' ),
	'kb_rollback_unavailable' => __( 'There is no valid previous knowledge base backup to restore.', 'leadbee' ),
	'email_test_sent' => __( 'The test email was accepted by the selected mailer.', 'leadbee' ),
	'email_test_failed' => __( 'The test email could not be sent. Check the configured recipient and mail server.', 'leadbee' ),
	'email_retry_sent' => __( 'The selected mailer accepted the notification retry. Check its log and the recipient inbox.', 'leadbee' ),
	'email_retry_failed' => __( 'The notification retry failed. The latest mail error is shown with the lead.', 'leadbee' ),
	'email_retry_disabled' => __( 'Email notifications are disabled in General Settings.', 'leadbee' ),
	'appearance_reset' => __( 'Appearance settings were restored to the bundled Yello defaults.', 'leadbee' ),
);
?>
<div class="wrap leadbee-admin">
	<div class="leadbee-page-head">
		<div class="leadbee-brand-mark">LB</div>
		<div><p class="leadbee-eyebrow">LEADBEE · YELLO DRIVING SCHOOL</p><h1><?php echo esc_html( $title ); ?></h1><p class="leadbee-subtitle"><?php esc_html_e( 'Manage chatbot conversations, enquiries and customer-facing settings.', 'leadbee' ); ?></p></div>
	</div>
	<?php if ( $notice && isset( $messages[ $notice ] ) ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html( $messages[ $notice ] ); ?></p></div><?php endif; ?>
	<?php if ( isset( $_GET['updated'] ) ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Lead details were updated.', 'leadbee' ); ?></p></div><?php endif; ?>
	<?php if ( isset( $_GET['deleted'] ) ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Selected lead records were deleted.', 'leadbee' ); ?></p></div><?php endif; ?>
