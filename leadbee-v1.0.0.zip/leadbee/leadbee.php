<?php
/**
 * Plugin Name: LeadBee
 * Description: Customisable conversational chatbot and lead management plugin.
 * Version: 1.0.0
 * Author: devxady
 * Author URI: https://adyverse.tech/
 * Text Domain: leadbee
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LEADBEE_VERSION', '1.0.0' );
define( 'LEADBEE_FILE', __FILE__ );
define( 'LEADBEE_PATH', plugin_dir_path( __FILE__ ) );
define( 'LEADBEE_URL', plugin_dir_url( __FILE__ ) );

require_once LEADBEE_PATH . 'includes/class-leadbee-database.php';
require_once LEADBEE_PATH . 'includes/class-leadbee-knowledge-base.php';
require_once LEADBEE_PATH . 'includes/class-leadbee-security.php';
require_once LEADBEE_PATH . 'includes/class-leadbee-leads.php';
require_once LEADBEE_PATH . 'includes/class-leadbee-mailer.php';
require_once LEADBEE_PATH . 'includes/class-leadbee-rest-api.php';
require_once LEADBEE_PATH . 'public/class-leadbee-public.php';
require_once LEADBEE_PATH . 'admin/class-leadbee-admin.php';
require_once LEADBEE_PATH . 'includes/class-leadbee-loader.php';

register_activation_hook( __FILE__, array( 'LeadBee_Loader', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'LeadBee_Loader', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'LeadBee_Loader', 'instance' ) );
